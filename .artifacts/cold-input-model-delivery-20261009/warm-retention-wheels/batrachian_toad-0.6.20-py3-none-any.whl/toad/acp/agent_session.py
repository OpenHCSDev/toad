"""ACP session handshake, durable metadata and reconnection custody."""
from __future__ import annotations
from agent_comms.declared_family import DeclaredFamily
from agent_comms.child_process import join_retirement
import asyncio
import os
from dataclasses import replace
import toad
from toad import constants, jsonrpc
from toad.core import events as core_events
from toad.acp import api
from acp import schema
from toad.acp.client_session import ClientSessionRequest
from toad.core.events import AgentReady, UnsupportedResumeAgentFail, LogAgentFail
from toad.db import DB, SessionMeta
from agent_comms.acp_failure import ACPFailure
from agent_comms.input_attempt import NotSentInput
from agent_comms.session_load import EnsuringSessionLoadAdmission, ExistingSessionLoadAdmission, FailedSessionLoadAdmission, SessionLoadAdmission

PROTOCOL_VERSION = 1


class SessionDisposition(DeclaredFamily, affix="SessionDisposition"):
    accepts_updates = False

    def close(self, agent):
        return self


class ActiveSessionDisposition(SessionDisposition):
    accepts_updates = True

    def close(self, agent):
        agent.controller.connection_closed()
        return ClosedSessionDisposition()


class ClosedSessionDisposition(SessionDisposition):
    pass


class AgentSession:
    """Own readiness and durable session effects; binding identity stays on the controller."""
    def __init__(self, agent, pk):
        self.agent = agent
        self.task = None
        self.responses = set()
        self.retirement = None
        self.disposition = ActiveSessionDisposition()
        self.pk = pk
        self.pending_name = None
        self.connected = False
        self.reconnecting = False
        self.load_admission: SessionLoadAdmission = EnsuringSessionLoadAdmission()
        self.settled = asyncio.Event()

    @property
    def capabilities(self):
        response = self.agent.process.initialization
        return (response.agent_capabilities if response is not None
                and response.agent_capabilities is not None else schema.AgentCapabilities())

    @property
    def accepts_updates(self):
        return self.disposition.accepts_updates

    def accepts_session(self, session_id: str | None) -> bool:
        """Only this active session may consume work for its current binding."""
        return self.accepts_updates and self.agent.session_id == session_id

    def start_operation(self, operation):
        task = asyncio.create_task(operation)
        if not self.accepts_updates:
            task.cancel()
        self.responses.add(task)
        task.add_done_callback(self.responses.discard)
        return task

    def close(self):
        self.disposition = self.disposition.close(self.agent)

    def reopen(self):
        self.disposition = ActiveSessionDisposition()
        self.retirement = None

    def start(self):
        self.task = asyncio.create_task(self.run())
        self.task.add_done_callback(self.session_finished)

    async def retire(self):
        self.close()
        if self.retirement is None:
            self.retirement = asyncio.create_task(self._retire())
        await join_retirement(self.retirement)

    async def _retire(self):
        pending = tuple(task for task in (self.task, *self.responses)
                        if task is not None)
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        self.responses.clear()
        self.task = None
        await self.agent.process.detach(self)

    def session_finished(self, task):
        if task.cancelled():
            return
        error = task.exception()
        if error is not None and self.accepts_updates:
            self.startup_failed(f"{type(error).__name__}: {error}")
            self.retirement = asyncio.create_task(self._retire())
            self.retirement.add_done_callback(self.retirement_finished)

    def retirement_finished(self, task):
        if task.cancelled():
            return
        error = task.exception()
        if error is not None:
            self.agent.log(f"[error] Session retirement failed: {error}")

    def session_failed(self, failure):
        self.close()
        self.failed()
        self.agent.events.publish(LogAgentFail(failure.title, failure.feedback, log_path=self.agent.presentation.log_path))

    def startup_failed(self, details):
        self.close()
        self.failed()
        self.agent.events.publish(LogAgentFail("ACP session startup failed", details=details, log_path=self.agent.presentation.log_path))

    @property
    def supports_images(self):
        prompt = self.capabilities.prompt_capabilities
        return prompt is not None and prompt.image

    @property
    def ready(self):
        return self.connected and self.settled.is_set()

    @property
    def supports_load(self):
        return self.capabilities.load_session

    def starting(self):
        """Start admission clears readiness before any asynchronous work."""
        self.connected = False
        self.settled.clear()
        self.agent.controller.reset_configuration()

    def closed(self):
        self.connected = False

    def failed(self):
        self.closed()
        self.settled.set()

    async def touch(self):
        if self.pk is not None:
            await DB().session_update_last_used(self.pk)

    def coordinated_title(self, title):
        from toad.core.events import SessionInfoUpdate
        self.agent.events.publish(SessionInfoUpdate(self.pending_name or title))
        if self.pending_name is not None:
            self.rename_coordination(self.pending_name)
            self.pending_name = None

    async def run(self) -> None:
        """The main logic of the Agent."""
        if constants.ACP_INITIALIZE:
            self.connected = False
            try:
                await self.initialize()
                if self.agent.controller.session.bound:
                    if not self.supports_load:
                        self.agent.events.publish(
                            UnsupportedResumeAgentFail(
                                "Resume not supported",
                                f"{self.agent.definition.name} does not currently support resuming sessions.",
                            )
                        )
                        self.settled.set()
                        return
                    await self.load()
                    await self.touch()
                else:
                    await self.new()
                self.connected = True
            except jsonrpc.APIError as error:
                # The handshake has not admitted a prompt, regardless of the
                # server's reason for refusing this attachment.
                failure = replace(ACPFailure.from_error(error.code, error.message, error.data),
                                  input_state=NotSentInput)
                self.session_failed(failure)
                return
        self.settled.set()
        self.agent.events.publish(AgentReady(reconnected=self.reconnecting))


    @property
    def needs_reattachment(self) -> bool:
        return not self.connected and self.settled.is_set() and not self.reconnecting

    async def observe_owner(self, presentation) -> None:
        """A new canonical owner may repair this failed read-only attachment."""
        if not self.needs_reattachment or presentation is None:
            return
        coordination = self.agent.coordination
        if coordination is None:
            return
        binding = presentation.binding
        if not self.load_admission.superseded_by(binding):
            return
        await self.reconnect(ExistingSessionLoadAdmission(binding))

    async def reconnect(self, admission: SessionLoadAdmission | None = None) -> None:
        """Reattach the existing view after login or an explicit owner start."""
        if self.agent.controller.session.bound and not self.supports_load:
            raise ValueError("This agent cannot resume its session.")
        from .maintenance_ingress import configured_root, preflight

        requested_env = os.environ.copy()
        requested_cwd = str(self.agent.project_root_path.resolve())
        requested_root = configured_root(requested_env, requested_cwd)
        try:
            await asyncio.to_thread(
                preflight,
                (self.agent.coordination.wire_root if self.agent.coordination else None),
                ingress_root=requested_root,
                cwd=requested_cwd,
            )
        except Exception as error:
            raise ValueError(
                f"Reconnect not attempted: maintenance admission denied: {error}"
            ) from error
        self.reconnecting = True
        try:
            await self.agent.stop()
            self.load_admission = admission or EnsuringSessionLoadAdmission()
            self.settled.clear()
            await self.agent.start((self.agent.process,))
            await asyncio.wait_for(self.settled.wait(), timeout=30)
            if not self.connected:
                raise ValueError("The agent could not reconnect.")
        finally:
            self.reconnecting = False


    async def authenticate(self, method_id: str) -> None:
        authority = ClientSessionRequest(self.agent, self.agent.session_id)
        authority.require()
        with self.agent.request():
            response = api.authenticate(method_id)
        await response.wait()
        authority.require()
        await self.initialize(force=True)
        authority.require()


    async def initialize(self, *, force=False):
        """The connection owns its original initialization response."""
        authority = ClientSessionRequest(self.agent, self.agent.session_id)
        authority.require()
        response = self.agent.process.initialization
        if response is None or force:
            with self.agent.request():
                initialize_response = api.initialize(
                    PROTOCOL_VERSION,
                    schema.ClientCapabilities(fs=schema.FileSystemCapabilities(
                        read_text_file=True, write_text_file=True), terminal=True,
                        auth=schema.AuthCapabilities(terminal=os.name != "nt")),
                    schema.Implementation(name=toad.NAME, title=toad.TITLE, version=toad.get_version()),
                )
            response = await initialize_response.wait()
            authority.require()
            assert response is not None
            self.agent.process.initialization = response
        authority.require()


    async def new(self) -> None:
        """Create a new session."""
        authority = ClientSessionRequest(self.agent, self.agent.session_id)
        authority.require()
        cursor_token = self.agent._private_cursor.begin(None)
        queue_token = self.agent.queue_attachment.begin(None)
        self.agent._post_private_cursor()
        self.agent._post_queue_view()
        with self.agent.request():
            session_new_response = api.session_new(
                str(self.agent.project_root_path),
                [],
            )
        response = await session_new_response.wait()
        authority.require()
        if not self.agent._private_cursor.is_current_request(cursor_token):
            return
        assert response is not None
        self.agent.session_id = response.session_id
        authority = ClientSessionRequest(self.agent, self.agent.session_id)
        await self.agent.comms_consumer_class(
            self.agent, self.agent.session_id,
            cursor_token=cursor_token, queue_token=queue_token,
        ).consume_metadata(response.field_meta)

        if self.supports_load:
            db = DB()
            session_name = (
                self.pending_name
                if self.pending_name is not None
                else (self.agent.coordination.title if self.agent.coordination else "New Session")
            )
            session_pk = await db.session_new(
                session_name,
                self.agent.definition.name,
                self.agent.definition.identity,
                self.agent.session_id,
                protocol="acp",
                meta=SessionMeta(
                    cwd=self.agent.project_root_path, agent_data=self.agent.definition
                ),
            )
            authority.require()
            if not self.agent._private_cursor.is_current_request(cursor_token):
                return
            self.pk = session_pk
            if self.pk is not None and self.pending_name is not None:
                await db.session_update_title(
                    self.pk, self.pending_name
                )
                authority.require()

        if not self.agent._private_cursor.is_current_request(cursor_token):
            return
        self.publish_configuration(response)


    async def load(self) -> None:
        authority = ClientSessionRequest(self.agent, self.agent.session_id)
        authority.require()
        assert self.agent.controller.session.bound, "Session id must be set"
        request_session_id = self.agent.session_id
        cursor_token = self.agent._private_cursor.begin(request_session_id)
        queue_token = self.agent.queue_attachment.begin(request_session_id)
        self.agent._post_private_cursor()
        self.agent._post_queue_view()
        cwd = str(self.agent.project_root_path)
        if self.pk is not None:
            db = DB()
            session = await db.session_get(self.pk)
            authority.require()
            if not self.agent._private_cursor.is_current_request(cursor_token):
                return
            if session is not None:
                if session_cwd := session.meta_json.cwd:
                    cwd = str(session_cwd)
                if agent_data := session.meta_json.agent_data:
                    self.agent.definition = agent_data

        admission, self.load_admission = self.load_admission, EnsuringSessionLoadAdmission()
        with self.agent.request():
            session_load_response = api.session_load(cwd, [], request_session_id,
                                                     admission.metadata())
        try:
            response = await session_load_response.wait()
        except jsonrpc.APIError as error:
            authority.require()
            if self.agent.queue_attachment.is_current_request(queue_token):
                if failed_command := FailedSessionLoadAdmission.from_failure(error.data):
                    self.load_admission = failed_command
            raise
        authority.require()
        if (
            not self.agent._private_cursor.is_current_request(cursor_token)
            or self.agent.session_id != request_session_id
        ):
            return
        assert response is not None
        await self.agent.comms_consumer_class(
            self.agent, self.agent.session_id,
            cursor_token=cursor_token, queue_token=queue_token,
        ).consume_metadata(response.field_meta)

        self.publish_configuration(response)


    def rename_coordination(self, display_name: str) -> None:
        if not self.accepts_session(self.agent.session_id):
            return
        thread = self.agent.coordination.thread.name if self.agent.coordination else None
        wire_root = self.agent.coordination.wire_root if self.agent.coordination else None
        if thread is None or wire_root is None:
            return

        from agent_comms.comms import wire

        result = wire(wire_root).threads.rename_managed_thread(
            thread,
            display_name,
            owner_pid=self.agent.coordination.owner_pid,
        )
        self.agent.coordination = replace(
            self.agent.coordination,
            thread=replace(self.agent.coordination.thread, name=result.current),
            title=display_name,
        )
        self.agent.events.publish(core_events.CommsUpdated(self.agent.coordination, self.agent.session_id))


    async def set_mode(self, mode_id: str) -> str | None:
        """Update the current mode with the agent."""
        authority = ClientSessionRequest(self.agent, self.agent.session_id)
        authority.require()
        with self.agent.request():
            response = api.session_set_mode(self.agent.session_id, mode_id)
        try:
            await response.wait()
            authority.require()
        except jsonrpc.APIError as error:
            return ACPFailure.from_error(error.code, error.message, error.data).feedback
        else:
            self.agent.controller.update_mode(mode_id)
            return None


    async def set_name(self, name: str) -> None:
        self.pending_name = name
        self.rename_coordination(name)
        if (self.agent.coordination.thread.name if self.agent.coordination else None) is not None:
            self.pending_name = None
        if self.pk is None:
            return
        db = DB()
        await db.session_update_title(self.pk, name)


    def publish_configuration(self, response):
        self.load_admission = SessionLoadAdmission.at_response(response.field_meta)
        if (modes := response.modes) is not None:
            self.agent.controller.publish_modes(modes)
        self.agent.configuration.receive(response.config_options)
