"""Operational read custody; rich pager retirement does not discard source reuse."""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from dataclasses import dataclass
from functools import partial
from pathlib import Path

from agent_comms.comms import wire
from agent_comms.acp_extension import TranscriptSnapshotUpdate
from agent_comms.coordination_errors import StaleRevision
from agent_comms.transcripts import TranscriptRead, TranscriptPage, TranscriptReadIdentity

from toad.work_preparation import (
    ScopedWork, SerializedWork, ThreadWork, PreparationRuntime, WorkKey,
)


@dataclass(frozen=True)
class NativeTranscriptReadWork(ScopedWork[TranscriptPage],
                               SerializedWork[TranscriptPage], ThreadWork[TranscriptPage]):
    read: TranscriptRead

    @property
    def work_key(self) -> WorkKey:
        # The source owner names page content independently of annotations.
        # Notification/reader changes refresh their projections without causing
        # another native history read or inventing a second source identity.
        return WorkKey(NativeTranscriptReadWork, self.read.identity.content_identity)

    def prepare(self) -> TranscriptPage:
        return self.read.read()


@dataclass(frozen=True)
class PublishedNativeTranscriptReadWork(NativeTranscriptReadWork):
    page: TranscriptPage

    def prepare(self) -> TranscriptPage:
        if not self.read.content_current():
            raise StaleRevision("Published transcript inputs changed before admission")
        return self.page


class CoordinationTranscriptReader(ABC):
    """One read-side Comms service, shared by transcript/status/owner requests."""

    def __init__(self):
        self._reader = None
        self._lock = asyncio.Lock()

    @abstractmethod
    async def deliver(self, work: NativeTranscriptReadWork) -> TranscriptPage: ...

    async def service(self, root):
        return await asyncio.to_thread(wire, root)

    def with_runtime(self, runtime: PreparationRuntime, access) -> CoordinationTranscriptReader:
        return PreparedTranscriptReadDelivery(runtime, access)

    @asynccontextmanager
    async def bind(self, root: str):
        async with self._lock:
            if self._reader is None or self._reader.root != Path(root).expanduser():
                self._reader = await self.service(root)
            reader = self._reader
        # The lock owns service initialization/replacement, not projections.
        # Each caller retains this exact root service; its canonical stores own
        # read transactions and the Agent fences publication after awaits.
        yield reader

    async def publication(self, update: TranscriptSnapshotUpdate) -> TranscriptSnapshotUpdate:
        identity = update.identity
        async with self.bind(identity.root) as reader:
            read = TranscriptRead(reader.transcripts, identity)
        try:
            page = await self.deliver(PublishedNativeTranscriptReadWork(read, update.page))
        except StaleRevision:
            return await self.snapshot(identity.root, identity.requested_name,
                before=identity.before, after=identity.after, through=identity.through,
                historical_source=identity.historical_source)
        if not await asyncio.to_thread(read.content_current):
            return await self.snapshot(identity.root, identity.requested_name,
                before=identity.before, after=identity.after, through=identity.through,
                historical_source=identity.historical_source)
        return TranscriptSnapshotUpdate(page, identity)

    async def notifications(self, root, references):
        async with self.bind(root) as reader:
            return await asyncio.to_thread(reader.views.message_notifications_for_references, references)

    async def page(self, root, thread, *, before=None, after=None, through=None,
                   read_identity: TranscriptReadIdentity | None = None,
                   historical_source: str | None = None):
        snapshot = await self.snapshot(root, thread, before=before, after=after, through=through,
                                       read_identity=read_identity, historical_source=historical_source)
        return snapshot.page

    async def snapshot(self, root, thread, *, before=None, after=None, through=None,
                       read_identity: TranscriptReadIdentity | None = None,
                       historical_source: str | None = None):
        async with self.bind(root) as reader:
            if read_identity is None:
                request = partial(reader.transcripts.capture_page_read, thread,
                                  historical_source=historical_source)
            else:
                if historical_source is not None and historical_source != read_identity.historical_source:
                    raise StaleRevision("Published transcript belongs to another recorded source")
                request = partial(reader.transcripts.bind_page_read, thread, read_identity)
            read = await asyncio.to_thread(request, before=before, after=after, through=through)
        page = await self.deliver(NativeTranscriptReadWork(read))
        # The preparation cache may supply an earlier result. Its original
        # content witness still has to admit it; annotations refresh separately.
        if not await asyncio.to_thread(read.content_current):
            raise StaleRevision("Transcript content changed before publication")
        return TranscriptSnapshotUpdate(page, read.identity)


class DirectTranscriptReadDelivery(CoordinationTranscriptReader):
    """An operational Agent can read before an application is attached."""

    async def deliver(self, work):
        return await asyncio.to_thread(work.prepare)


class PreparedTranscriptReadDelivery(CoordinationTranscriptReader):
    """Use the application's existing globally bounded worker/cache owner."""

    def __init__(self, runtime: PreparationRuntime, access):
        super().__init__()
        self.runtime = runtime
        self.access = access

    async def deliver(self, work):
        return await self.runtime.submit(work)

    async def service(self, root):
        shared = self.access.observed_service
        if shared is not None and shared.root == Path(root).expanduser():
            return shared
        return await super().service(root)

    def with_runtime(self, runtime, access):
        return (self if self.runtime is runtime and self.access is access
                else super().with_runtime(runtime, access))
