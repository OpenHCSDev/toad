"""Native Toad conversation view for an agent-comms channel or DM."""

from __future__ import annotations
from toad.core import input_events
from functools import partial
from toad.delivery_failure_view import DeliveryFailureView
from toad.mounted_message_history import MountedMessageHistory, WireMessageStyle
from agent_comms.thread_identity import ThreadRole
from toad.widgets.irc_message import MembershipNotice

import asyncio
import re
from collections.abc import Callable
from pathlib import Path

from agent_comms.comms import Comms
from agent_comms.field_codec import FieldCodec
from agent_comms.mro_dispatch import handles
from toad.core import events as core_events
from toad.core.source_events import TranscriptSourceWorkFinished
from toad.message_viewport import NotificationViewport
from agent_comms.messages import Message as WireMessage
from textual import containers, work
from textual.app import ComposeResult
from textual.content import Content
from textual.widgets import Static
from textual.widget import Widget
from textual.worker import Worker

from toad.conversation_kind import ConversationKind
from toad import messages
from toad.widgets.conversation import (
    Contents,
    ContentsGrid,
    Conversation,
    CursorContainer,
    Window,
)
from toad.widgets.flash import Flash
from toad.widgets.prompt import Prompt
from toad.owner_preparation import read_thread_presentation
from toad.screens.session_view import SessionView
from toad.command_catalog import CommandCatalog


def _comms_root() -> Path:
    from toad.comms_root import current_root

    return current_root()


def session_thread_name(project_path) -> str:
    """The wire thread name for a Toad project directory (ACP naming)."""
    return (
        re.sub(r"[^A-Za-z0-9_-]+", "-", Path(project_path).name or "session").strip("-")
        or "session"
    )


def resolve_session_thread(
    comms, project_path: Path, preferred: str | None = None, *, source_root: str | None = None,
) -> str | None:
    """Resolve an exact bound thread or an unbound project's registry identity."""
    if source_root is not None:
        if Path(source_root).expanduser().resolve() != comms.root.resolve():
            raise ValueError("Comms route changed; this session retains its former wire")
        return comms.registry.require(preferred).name
    project = Path(project_path).expanduser().resolve()
    threads = comms.registry.all_threads()
    if preferred:
        preferred = comms.registry.canonical_name(preferred)
    if (
        preferred in threads
        and Path(threads[preferred].worktree).expanduser().resolve() == project
    ):
        return preferred
    matches = [
        name
        for name, thread in threads.items()
        if Path(thread.worktree).expanduser().resolve() == project
        and "acp" in thread.tags
    ]
    if len(matches) == 1:
        return matches[0]
    return None


from toad.block_navigation import ConversationBlock


class HistoryLoading(ConversationBlock, Static):
    """Channel history loading is an atomic conversation block."""


class ChannelActivityTray(ConversationBlock, containers.VerticalGroup):
    """Channel activity has one declared navigation boundary."""


class CommsChatView(DeliveryFailureView, Conversation):
    """A wire-backed conversation using Toad's normal transcript primitives."""

    BINDINGS = Conversation.BINDINGS[:5]

    def __init__(
        self,
        project_path: Path,
        *,
        target: str,
        kind: type[ConversationKind],
        me: str,
        wire_root: str | None = None,
    ) -> None:
        super().__init__(project_path)
        self.target = target
        self.conversation_kind = kind
        self._me = me
        self._unknown_send: tuple[str, int, str] | None = None
        self._human_admission_blocked = False
        self._send_block_reason = ""
        self._bound_root = Path(wire_root).resolve() if wire_root is not None else None
        self.input_histories.bind_scope(f"comms:{FieldCodec.encode(kind)}:{target}")
        self.message_history = MountedMessageHistory(self)
        self._notification_task: asyncio.Task[None] | None = None

    def compose(self) -> ComposeResult:
        with Window():
            with ContentsGrid():
                yield CursorContainer(id="cursor-container")
                with Contents(id="contents"):
                    yield self.message_history
                    yield ChannelActivityTray(id="comms-activity")
        yield Flash()
        with containers.Vertical(id="prompt-stack"):
            yield self.conversation_kind.activity_widget(self)
            yield self.make_throbber()
            yield self.conversation_kind.prompt(self.target).data_bind(
                project_path=Conversation.project_path,
                working_directory=Conversation.working_directory,
                agent_info=Conversation.agent_info,
                agent=Conversation.agent,
                status=Conversation.status,
            )

    async def initialize_view(self) -> None:
        # Reuse the canonical core service already shared by tab sidebars and
        # transcript readers. Its revision-aware caches remain model-owned.
        try:
            root = await self.app.preparation.run_thread(_comms_root)
        except (OSError, ValueError, RuntimeError):
            self.display = False
            return
        if self._bound_root is not None and root != self._bound_root:
            self.display = False
            return
        from toad.channel_preparation import ChannelHistoryReader, InitialHistoryReadRequest
        from toad.mounted_message_history import (
            INITIAL_HISTORY_PAGE_SIZE, HISTORY_PAGE_SIZE, HISTORY_PAGE_BYTES,
        )

        shared = await self.app.preparation.run_thread(
            lambda: self.app.coordination_access.service)
        if shared.root != root:
            self.display = False
            return
        comms = shared
        self.message_history.reader = ChannelHistoryReader(InitialHistoryReadRequest(
            comms, self.conversation_kind, self.target, Path(self.project_path),
            INITIAL_HISTORY_PAGE_SIZE, HISTORY_PAGE_SIZE, HISTORY_PAGE_BYTES,
        ))
        self.agent_info = Content(self._target_label())
        self.agent_ready = True
        self.prepare_prompt()
        self.window.anchor()
        # CommsScreen has already presented its route before mounting this
        # view. Start its asynchronous page read now, overlapping it with the
        # remaining control mounts rather than waiting for another empty
        # history frame. The original pager admits its asynchronous source read.
        await self._refresh()

    @handles(core_events.CoordinationObserved)
    async def _command_source_changed(self, event) -> None:
        """One canonical observation invalidates commands and the mounted source."""
        await super()._command_source_changed(event)
        await self._refresh()

    @handles(core_events.SessionSelected)
    async def _selected_source_changed(self, event) -> None:
        """A retained view reads current source after its original tab admission."""
        await super()._selected_commands_changed(event)
        await self._refresh()

    @handles(TranscriptSourceWorkFinished)
    async def on_transcript_source_work_finished(self, event) -> None:
        """Reconcile an observation which arrived during this source's work."""
        super().on_transcript_source_work_finished(event)
        history = self.message_history
        reader = history.reader
        access = self.app.coordination_access
        if (event.publisher is not history or reader is None
                or not history.state.accepts_source_work
                or reader.source.loading
                or reader.comms is not access.observed_service
                or access.revision is None
                or reader.source.matches_revision(access.revision)):
            return
        snapshot = history.source_snapshot()
        if not snapshot.current(history):
            return
        # A read can also be newer than the observer's last publication. Their
        # file revisions are identities, not an ordering: check the original
        # service before admitting more work rather than repeatedly rereading
        # an already-current page until the observer's next tick.
        try:
            revision = await self.app.preparation.run_thread(reader.comms.views.revision)
        except (OSError, ValueError, RuntimeError):
            # An unavailable/replaced route has no revision to admit. Its
            # original observer remains responsible for the next observation.
            return
        if (reader is history.reader and snapshot.current(history)
                and reader.comms is access.observed_service
                and not reader.source.matches_revision(revision)):
            await self._refresh()

    def prepare_prompt(self) -> None:
        """Apply comms prompt state after a mode becomes active."""
        prompt = self.query_one_optional(Prompt)
        if prompt is None:
            # A large Channels panel may mount its virtual rows before the
            # channel composer finishes composing its Prompt. Both its Mount
            # callback and the containing Screen's Mount callback can arrive
            # first; settle once after the committed first layout instead of
            # dereferencing an unmounted getter.
            if self.is_attached:
                self.call_after_refresh(self.prepare_prompt)
            return
        self.observe_core(self.app.coordination_access.events)
        self.observe_core(self.app.events)
        self.update_slash_commands()
        prompt.agent_info = self.agent_info
        prompt.sync_session()
        prompt.shell_mode = False
        prompt.update_prompt()
        from toad.screens.session_view import SessionView

        if self.query_ancestor(SessionView).is_current:
            prompt.focus()

    def watch_agent(self, agent) -> None:
        """Keep the inherited agent reactive from turning this into a shell session."""
        self.agent_info = Content(self._target_label())

    @work
    async def watch_agent_ready(self, ready: bool) -> None:
        """Comms readiness has no shell process to await."""

    def _target_label(self) -> str:
        return self.conversation_kind.label(self.target)






    def message_block(self, message: WireMessage, *, style: WireMessageStyle) -> Widget:
        """The view owns display direction and the membership-notice widget."""
        if message.membership is not None:
            return MembershipNotice(message)
        direction = ("User" if message.sender_role is ThreadRole.USER else
                     "Outbound" if message.sender == self._me else "Inbound")
        return style.block(message, direction=direction)

    def _refresh_notifications(self) -> None:
        """One bounded batch for the painted window; independent of bus revision."""
        if (not self.is_attached or self.message_history.reader is None
                or not self.display
                or self._notification_task is not None and not self._notification_task.done()):
            return
        rows = self._visible_notification_rows()
        if rows:
            self._notification_task = asyncio.create_task(self._read_notifications(rows))

    def _visible_notification_rows(self) -> tuple[tuple[WireMessage, Widget], ...]:
        return self.message_history.viewport(NotificationViewport).visible_rows()

    async def _read_thread_activity(self):
        history = self.message_history
        reader = history.reader
        if reader is None:
            return None
        snapshot = history.source_snapshot()
        comms, target = reader.comms, self.target
        if not await history.source_is_current(snapshot):
            raise ValueError("Comms route changed")
        presentation = await asyncio.to_thread(read_thread_presentation, comms, target)
        if not await history.source_is_current(snapshot) or target != self.target:
            raise ValueError("Comms route changed")
        return presentation

    async def _read_notifications(self, rows: tuple[tuple[WireMessage, Widget], ...]) -> None:
        history = self.message_history
        reader = history.reader
        if reader is None:
            return
        snapshot = history.source_snapshot()
        comms, target = reader.comms, self.target
        if not await history.source_is_current(snapshot):
            return
        error = None
        try:
            results = await asyncio.to_thread(
                comms.views.message_notifications, tuple(message for message, _ in rows),
            )
        except Exception as failure:
            error, results = failure, {}
        if not await history.source_is_current(snapshot) or self.target != target:
            return
        visible = {widget for _, widget in self._visible_notification_rows()}
        for message, widget in rows:
            if widget in visible:
                feedback = widget.notifications
                if feedback is None or not feedback.is_attached:
                    continue  # Style replacement has unmounted this row's children.
                if error is not None:
                    feedback.show_error(error)
                else:
                    feedback.show_result(results.get((message.seq, message.message_id), ()))

    async def _refresh(self) -> Worker | None:
        if not self.is_attached or self.message_history.reader is None:
            return
        if not self.query_ancestor(SessionView).is_current:
            return
        self._refresh_notifications()
        return self.message_history.schedule_source_work(self._refresh_source)

    async def _refresh_source(self) -> None:
        from agent_comms.coordination_errors import CoordinationReadUnavailable, StaleRevision

        try:
            history = self.message_history
            snapshot = history.source_snapshot()
            if not await history.source_is_current(snapshot):
                if snapshot.current(history):
                    self.display = False
                return
            reader = history.reader
            comms = reader.comms
            catalog = await asyncio.to_thread(comms.channels.catalog.read)
            if not await history.source_is_current(snapshot):
                return
            read_only = self.conversation_kind.read_only(catalog, self.target)
            if read_only:
                self.prompt.prompt_text_area.disabled = True
                self.prompt.prompt_text_area.tooltip = "Saved view: read-only history; open an exact channel to send"
                self.status = "Read-only saved view"
            show_loading = self.message_history.reader.source.loading
            if show_loading:
                self.on_work_started()
            try:
                read = await reader.read(self.message_history.follows_tail)
            finally:
                if show_loading:
                    self.on_work_finished()
            if not await history.source_is_current(snapshot):
                if snapshot.current(history):
                    self.display = False
                return
            if not reader.current(read, self.message_history.follows_tail):
                return
            revision = read.revision
            if reader.source.matches_revision(revision):
                self.call_after_refresh(self.message_history.mark_visible)
                return
            # Show the bounded tail before computing roster/sort metadata,
            # which can scan a much larger coordination history.
            if not await self.message_history.publish(read):
                return
            follow = read.follow_tail
            snapshot = history.source_snapshot()
            await self.conversation_kind.update_roster(self, comms)
            if not await history.source_is_current(snapshot):
                if snapshot.current(history):
                    self.display = False
                return
            if (not self.is_attached or reader is not self.message_history.reader
                    or not self.query_ancestor(SessionView).is_current):
                return
            self.call_after_refresh(self.message_history.mark_visible)
        except (CoordinationReadUnavailable, StaleRevision):
            raise
        except Exception as error:
            message = f"Wire error: {error}"
            if message != self.status:
                self.flash(message, style="error")
            self.status = message
            return

        target = self.target
        info = await self.conversation_kind.agent_info(comms, target)
        if not await history.source_is_current(snapshot) or self.target != target:
            return
        if self._unknown_send is not None:
            root_id, sequence, message_id = self._unknown_send
            self.status = (
                f"Send UNKNOWN {root_id}/{sequence}/{message_id}; "
                "inspect the bus, do not retry"
            )
        elif self._human_admission_blocked:
            self.status = self._send_block_reason
        elif info is not None:
            self.status = " · ".join(
                value
                for value in (info.model or "", info.context_label)
                if value
            )
        else:
            self.status = "Read-only saved view" if read_only else ""
        if follow and self.window.follows_tail:
            self.window.anchor()
        if self.message_history.has_newer or (self.message_history.has_older and self.window.max_scroll_y == 0):
            self.message_history.request_preparation()

    async def command_target_context(self):
        from toad.target_commands import TargetContext
        if self.message_history.reader is None:
            return None
        return TargetContext(self.app, self.message_history.reader.comms, self.target, self._me, self.project_path,
                             self.query_ancestor(SessionView).id)

    async def submit_input(self, event: input_events.UserInputSubmitted) -> None:
        if event.body.strip().startswith("/") and await CommandCatalog.execute(event.body.strip(), self):
            return
        if not event.body.strip():
            return
        if self._unknown_send is not None or self._human_admission_blocked:
            self.flash("Send pending/UNKNOWN/blocked; inspect, do not retry", style="error")
            return
        try:
            from toad.comms_root import implicit_root, root_is_current, run_selected_write

            reader = self.message_history.reader
            if (reader is None
                    or not await self.app.preparation.run_thread(root_is_current, reader.comms.root)
                    or reader is not self.message_history.reader):
                raise ValueError("Comms route changed; reopen this view before sending")
            comms = reader.comms
            catalog = await asyncio.to_thread(comms.channels.catalog.read)
            if self.conversation_kind.read_only(catalog, self.target):
                self.prompt.text = event.body
                self.prompt.prompt_text_area.disabled = True
                self.status = "Read-only saved view; open an exact channel to send"
                self.flash(self.status, style="error")
                return
            # Disable compose through both the worker and the subsequent
            # receipt paint. Cancellation after a committed receipt must not
            # leave an apparently fresh, send-ready draft.
            self._human_admission_blocked = True
            self._send_block_reason = "Send pending; do not retry"
            self.prompt.text = event.body
            self.prompt.prompt_text_area.disabled = True
            send_task = asyncio.create_task(
                asyncio.to_thread(
                    run_selected_write, comms.root, comms.messaging.send_user_message,
                    self.conversation_kind.send_target(self.target), event.body,
                    worktree=str(self.project_path), implicit=implicit_root(),
                )
            )
            try:
                receipt = await asyncio.shield(send_task)
            except asyncio.CancelledError:
                # Cancelling the UI coroutine does not cancel the worker. The
                # append may already have happened; never present this text as
                # send-ready or launch a second attempt on a different root.
                self._human_admission_blocked = True
                self.prompt.text = event.body
                self.prompt.prompt_text_area.disabled = True
                self._send_block_reason = (
                    "Send cancelled while worker may still write; "
                    "outcome UNKNOWN, inspect the bus, do not retry"
                )
                self.status = self._send_block_reason
                self.prompt.prompt_text_area.tooltip = self.status
                self.flash(self.status, style="error")
                send_task.add_done_callback(
                    lambda task: task.exception() if not task.cancelled() else None
                )
                return
        except Exception as error:
            from agent_comms.delivery_failure import delivery_failure

            delivery_failure(error).present(self, event.body)
            return
        self._send_block_reason = (
            f"Send receipt {comms.root}/{receipt.seq}/{receipt.message_id}; "
            "awaiting paint, do not retry"
        )
        self.status = self._send_block_reason
        self.prompt.prompt_text_area.tooltip = self.status
        try:
            await self._paint_sent_receipt(comms, receipt, event.body, root_is_current)
        except (asyncio.CancelledError, Exception) as error:
            reason = (
                "interrupted" if isinstance(error, asyncio.CancelledError) else "failed"
            )
            self._send_block_reason = (
                f"Committed send {comms.root}/{receipt.seq}/{receipt.message_id}; "
                f"paint {reason}, inspect before composing"
            )
            self.status = self._send_block_reason
            self.prompt.prompt_text_area.tooltip = self.status
            return
        if await self.app.preparation.run_thread(root_is_current, comms.root) and any(
            message.message_id == receipt.message_id and message.seq == receipt.seq
            for message, _ in self.message_history.rows
        ):
            self._human_admission_blocked = False
            self._send_block_reason = ""
            self.prompt.text = ""
            self.prompt.prompt_text_area.disabled = False
            self.prompt.prompt_text_area.tooltip = None
            self.status = ""

    async def _paint_sent_receipt(
        self, comms: Comms, receipt: WireMessage, body: str,
        root_is_current: Callable[[str | Path], bool],
    ) -> None:
        if not await self.app.preparation.run_thread(root_is_current, comms.root):
            # The send may already have reached the former wire. Do not
            # duplicate it on the successor or paint it under the new route.
            self.display = False
            self.flash(
                "Comms route changed during send; outcome may be uncertain",
                style="error",
            )
            return
        self.run_worker(partial(self.input_histories.prompt.record, body), group="history")
        await self.message_history.paint_receipt(receipt)
        await self._refresh()
