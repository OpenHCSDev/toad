"""Goal commands own behavior; one parent owns CAS, publication and actor checks."""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, ClassVar
from uuid import uuid4

from .child_process import ProcessIdentity
from .command import Command
from .declared_family import DeclaredFamily
from .goal_mentions import bind_goal_mentions
from .goal_states import (
    ActiveGoal,
    BlockedGoal,
    BlockedState,
    CompletedGoal,
    GoalState,
    OwnerPause,
    PausedGoal,
    RuntimePause,
)
from .goal_waits import GoalWait, GoalWaits
from .goals import Goal
from .threads import Thread

if TYPE_CHECKING:
    from .goal_attempts import GoalAttemptStore
    from .goal_management import Goals


class ModelInvocable:
    pass


class OwnerInvocable:
    pass


class RuntimeInvocable:
    pass


class OwnerControlInvocable:
    pass


@dataclass(frozen=True)
class GoalPrecondition:
    goal_id: str | None = None
    expected_state: GoalState | None = None
    expected_goal: Goal | None = None
    expected_owner: ProcessIdentity | None = None

    def check(self, ctx: GoalActionContext) -> None:
        thread, goal = ctx.thread, ctx.thread.goal
        if self.expected_owner is not None and (
            thread.process_identity != self.expected_owner
            or not ctx.goals.registry.status(thread.name).running
        ):
            raise ValueError("The goal owner changed; refresh its state.")
        if self.expected_goal is not None and goal != self.expected_goal:
            raise ValueError("Goal changed during resume; refresh its state.")
        if self.goal_id is not None:
            thread.require_goal(self.goal_id)
        if self.expected_state is not None and (
            goal is None or goal.state != self.expected_state
        ):
            raise ValueError(
                goal.state.activity_refusal() if goal is not None
                else "This goal is no longer active; refresh its state."
            )


@dataclass(frozen=True)
class GoalActionContext:
    goals: Goals
    thread: Thread
    actor: type = RuntimeInvocable
    owner_store: GoalAttemptStore | None = None

    @property
    def report_turn(self) -> str:
        return self.thread.turn_state.report_turn

    @property
    def model_report(self) -> bool:
        return self.actor is ModelInvocable

    def require_goal(self) -> Goal:
        return self.thread.require_goal()


@dataclass(frozen=True, kw_only=True)
class GoalAction(DeclaredFamily, Command, affix="GoalAction"):
    expect: GoalPrecondition = GoalPrecondition()
    preserve_wait: ClassVar[bool] = False
    owner_grant: ClassVar[bool] = False
    schedules_goal: ClassVar[bool] = False

    @classmethod
    def model_choices(cls) -> tuple[str, ...]:
        return tuple(member.declared_name for member in cls.members_with(ModelInvocable))

    @classmethod
    async def submit_control(
        cls,
        observe: Callable[[], Awaitable[tuple[Goal | None, object]]],
        invoke: Callable[..., Awaitable[dict]],
        text: str = "",
    ) -> dict:
        goal, _ = await observe()
        if goal is None:
            raise ValueError("The goal changed; refresh its state.")
        return await cls.submit_checkpoint(invoke, goal)

    @classmethod
    async def submit_checkpoint(cls, invoke: Callable[..., Awaitable[dict]], goal: Goal) -> dict:
        from .field_codec import FieldCodec
        from .runtime_requests import UpdateGoalRuntimeRequest

        return await invoke(
            FieldCodec.encode(UpdateGoalRuntimeRequest), status=cls,
            goal_id=goal.id, expected_revision=goal.revision,
        )

    def check_grant(self, ctx: GoalActionContext) -> None:
        if ctx.owner_store is not None:
            raise ValueError("Owner goal authority requires goal creation or explicit resume.")

    def apply(self, ctx: GoalActionContext) -> Goal | None:
        self.expect.check(ctx)
        if not isinstance(self, ctx.actor):
            raise ValueError(f"This actor cannot take goal action {self.declared_name!r}.")
        self.check_grant(ctx)
        if ctx.model_report and any(
            entry.reports_turn(ctx.report_turn)
            for entry in ctx.goals.registry.goal_history(ctx.thread.name)
        ):
            raise ValueError("This goal was already reported in this turn.")
        goal = self.change(ctx)
        self.before_publish(goal, ctx)
        ctx.goals.registry.register(
            replace(
                ctx.thread,
                goal=goal,
            ),
            ctx.goals.registry.status(ctx.thread.name),
        )
        if not self.preserve_wait and ctx.thread.goal is not None:
            ctx.goals.waits.clear(ctx.thread.goal.id)
        return goal

    @abstractmethod
    def change(self, ctx: GoalActionContext) -> Goal | None: ...

    def before_publish(self, goal: Goal | None, ctx: GoalActionContext) -> None:
        pass


@dataclass(frozen=True, kw_only=True)
class TransitionGoalAction(GoalAction):
    progress: str | None = None

    @abstractmethod
    def next_state(self, ctx: GoalActionContext) -> GoalState: ...

    def change(self, ctx: GoalActionContext) -> Goal:
        goal = ctx.require_goal()
        state = self.next_state(ctx)
        goal.state.check_transition(state, owner=ctx.actor is OwnerInvocable)
        self.before_transition(ctx)
        return replace(
            goal,
            state=state,
            revision=goal.revision + 1,
            progress=goal.progress if self.progress is None else self.progress,
            reported_turn=ctx.report_turn if ctx.model_report else goal.reported_turn,
        )

    def before_transition(self, ctx: GoalActionContext) -> None:
        pass


@dataclass(frozen=True, kw_only=True)
class ActiveGoalAction(
    TransitionGoalAction, ModelInvocable, OwnerInvocable, RuntimeInvocable, OwnerControlInvocable
):
    owner_grant = True
    schedules_goal = True

    def check_grant(self, ctx: GoalActionContext) -> None:
        if ctx.owner_store is not None and (
            ctx.actor is not OwnerInvocable or self.expect.expected_owner is None
        ):
            super().check_grant(ctx)

    def next_state(self, ctx: GoalActionContext) -> GoalState:
        return ActiveGoal()

    def before_transition(self, ctx: GoalActionContext) -> None:
        goal, thread = ctx.require_goal(), ctx.thread
        if ctx.owner_store is not None:
            generation = ctx.owner_store.snapshot(goal.id)
            if generation is None:
                raise ValueError("Goal launch authority is missing; inspect it before Retry.")
            if generation.lifecycle.failed and generation.attempt_id:
                # A failed/uncertain attempt needs the explicit Retry
                # decision, not a status-only Resume. Expose that state
                # immediately so the UI offers the correct control.
                # Persist the bounded refusal explanation so a reload
                # never shows 'reason unavailable' on a fresh row.
                refusal = required_block_reason(
                    "The interrupted goal attempt is unresolved. Inspect it, then use "
                    "Retry to authorize a new attempt. Your messages can still be sent."
                )
                blocked = replace(
                    goal,
                    state=BlockedGoal(refusal),
                    progress=goal.progress,
                    revision=goal.revision + 1,
                )
                ctx.goals.registry.register(
                    replace(thread, goal=blocked), ctx.goals.registry.status(thread.name)
                )
                raise ValueError(refusal)
            elif not generation.lifecycle.allows_resume(thread.executing):
                raise ValueError("The goal attempt is unresolved; inspect it before Retry.")


@dataclass(frozen=True, kw_only=True)
class StandbyGoalAction(TransitionGoalAction, ModelInvocable, RuntimeInvocable):
    wait_for: tuple[str, ...] = ()
    reviewed_inputs: tuple[str, ...] = ()
    preserve_wait = True

    def next_state(self, ctx: GoalActionContext) -> GoalState:
        return ActiveGoal()

    def before_publish(self, goal: Goal | None, ctx: GoalActionContext) -> None:
        assert goal is not None
        thread = ctx.thread
        report_turn = ctx.report_turn
        review = ctx.goals._goal_input_review(thread, goal.id, self.wait_for)
        wait_targets = review.targets
        from .input_disposition import InputDispositions

        aliases = review.owners
        dispositions = InputDispositions(ctx.goals.root / InputDispositions.filename)
        unknown = {row.key: row for row in review.unknown}
        reviewed_keys = tuple(dict.fromkeys(self.reviewed_inputs))
        if any(key not in unknown or unknown[key].sequence is None for key in reviewed_keys):
            raise ValueError("Review only this recipient's exact unresolved bus input keys.")
        if not set(reviewed_keys) <= review.eligible_keys:
            raise ValueError("Review only direct inputs from these declared dependencies.")
        pending = next(
            (
                row
                for row in review.unknown
                if row.key in review.eligible_keys
                and row.key not in reviewed_keys
                and not row.reviewed_for_goal(goal.id)
            ),
            None,
        )
        if pending is not None:
            sequence = pending.sequence
            raise ValueError(
                f"Dependency reply {sequence} is already pending or UNKNOWN. "
                f"Call comms_inbox with goal_id={goal.id!r} and "
                f"wait_for={list(self.wait_for)!r}. Inspect standby_review.messages, then "
                "pass only standby_review.reviewed_inputs to comms_goal to wait "
                "for a later reply. Do not pass excluded owner or other dependency inputs. "
                "This does not mark them STARTED or replay them."
            )
        snapshot = ctx.goals.registry.snapshot()
        if not any(
            GoalWaits.target_has_active_turn(target, snapshot)
            and snapshot.threads[snapshot.canonical_name(target.name)].process_alive
            for target in wait_targets
        ):
            names = ", ".join(f"@{target.name}" for target in wait_targets)
            raise ValueError(
                f"No declared dependency has an active turn ({names}). "
                "A running/ready process or queued input does not prove active work. "
                "Message or restart the responsible agent, inspect its status, "
                "then declare standby only while a target is actually working."
            )
        closed = GoalWaits.closed_wait_group(
            thread.name,
            wait_targets,
            ctx.goals.waits.read(),
            snapshot,
        )
        if closed:
            names = ", ".join(f"@{name}" for name in closed)
            raise ValueError(
                f"Standby would close a dependency wait group ({names}). "
                "At least one agent must remain able to work or reply. "
                "Continue independent work or change the dependencies."
            )
        dispositions.review_for_goal(
            reviewed_keys,
            observed=tuple(unknown[key] for key in reviewed_keys),
            owners=aliases,
            goal_id=goal.id,
            goal_revision=goal.revision,
            turn_id=report_turn,
        )
        # Commit scheduling authority first. A crash before the registry
        # progress update must leave this same goal waiting, not runnable.
        reporting_lease = thread.turn_lease
        ctx.goals.waits.record(
            GoalWait(
                goal.id,
                uuid4().hex,
                goal.revision,
                ctx.goals.bus.log.latest_sequence(),
                wait_targets,
                owner_created_at=thread.created_at,
                report_turn_id=reporting_lease.turn_id if reporting_lease is not None else None,
                report_turn_generation=(
                    reporting_lease.identity.generation if reporting_lease is not None else None
                ),
                target_turn_generations=tuple(
                    (
                        snapshot.threads[
                            snapshot.canonical_name(target.name)
                        ].turn_generation
                        if GoalWaits.target_has_active_turn(target, snapshot)
                        else None
                    )
                    for target in wait_targets
                ),
            )
        )


@dataclass(frozen=True, kw_only=True)
class CompletedGoalAction(TransitionGoalAction, ModelInvocable, OwnerInvocable, RuntimeInvocable):
    def next_state(self, ctx: GoalActionContext) -> GoalState:
        return CompletedGoal()


@dataclass(frozen=True, kw_only=True)
class BlockedGoalAction(TransitionGoalAction, ModelInvocable, OwnerInvocable, RuntimeInvocable):
    block_reason: str | None = None

    def next_state(self, ctx: GoalActionContext) -> GoalState:
        return BlockedGoal(
            required_block_reason(
                self.block_reason if self.block_reason is not None else self.progress
            )
        )


@dataclass(frozen=True, kw_only=True)
class PausedGoalAction(
    TransitionGoalAction, OwnerInvocable, RuntimeInvocable, OwnerControlInvocable
):
    def next_state(self, ctx: GoalActionContext) -> GoalState:
        current = ctx.require_goal().state.pause_source
        return PausedGoal(
            current or (OwnerPause() if ctx.actor is OwnerInvocable else RuntimePause())
        )


@dataclass(frozen=True, kw_only=True)
class ReplacementGoalAction(GoalAction):
    def before_publish(self, goal: Goal | None, ctx: GoalActionContext) -> None:
        goal = ctx.thread.goal
        if goal is not None:
            # Revoke a protected goal before removing or replacing its
            # registry identity. If the registry write then fails, the
            # remaining visible goal is safely unlaunchable.
            from .goal_attempts import GoalAttemptStore

            private = ctx.goals.root / "goal-private"
            if (private / "goal_attempts.sqlite3").exists():
                attempts = GoalAttemptStore(private)
                generation = attempts.snapshot(goal.id)
                if generation is not None and not generation.lifecycle.terminal:
                    attempts.retire_goal(
                        goal.id,
                        expected_generation=generation.number,
                        attempt_id=generation.attempt_id,
                    )


@dataclass(frozen=True, kw_only=True)
class SetGoalAction(ReplacementGoalAction, OwnerInvocable, RuntimeInvocable):
    text: str

    @classmethod
    async def submit_control(cls, observe, invoke, text: str = "") -> dict:
        from .field_codec import FieldCodec
        from .runtime_requests import SetGoalRuntimeRequest

        return await invoke(FieldCodec.encode(SetGoalRuntimeRequest), text=text)

    def check_grant(self, ctx: GoalActionContext) -> None:
        pass

    def change(self, ctx: GoalActionContext) -> Goal:
        goal = Goal(text=self.text.strip(), id=uuid4().hex, revision=1)
        goal = replace(
            goal,
            mention_source=bind_goal_mentions(
                goal.text, goal.id, goal.revision, ctx.thread, ctx.goals.registry.snapshot()
            ),
        )
        if ctx.owner_store is not None:
            ctx.owner_store.create_goal(goal.id)
        return goal


@dataclass(frozen=True, kw_only=True)
class ClearGoalAction(
    ReplacementGoalAction, OwnerInvocable, RuntimeInvocable, OwnerControlInvocable
):
    def change(self, ctx: GoalActionContext) -> None:
        return None


@dataclass(frozen=True, kw_only=True)
class EditGoalAction(GoalAction, OwnerInvocable, RuntimeInvocable):
    text: str
    preserve_wait = True

    def change(self, ctx: GoalActionContext) -> Goal:
        goal = ctx.require_goal()
        text = self.text.strip()
        if not text:
            raise ValueError("A goal requires text.")
        revision = goal.revision + 1
        return replace(
            goal,
            text=text,
            revision=revision,
            mention_source=bind_goal_mentions(
                text, goal.id, revision, ctx.thread, ctx.goals.registry.snapshot()
            ),
        )


def required_block_reason(reason: str | None) -> str:
    """Validate the block's own reason, independently of prior progress."""
    if type(reason) is not str or not reason.strip():
        raise ValueError("Blocking a goal requires a nonempty reason for the needed input.")
    normalized = reason.strip()
    if len(normalized) > 1024:
        raise ValueError("A blocked-goal reason must be at most 1024 characters.")
    return normalized


@dataclass(frozen=True, kw_only=True)
class RetryGoalAction(GoalAction, OwnerInvocable):
    """Explicit owner retry; existing store grants still fence every attempt."""

    @classmethod
    async def submit_checkpoint(cls, invoke, goal: Goal) -> dict:
        from .field_codec import FieldCodec
        from .runtime_requests import RetryGoalRuntimeRequest

        return await invoke(
            FieldCodec.encode(RetryGoalRuntimeRequest),
            goal_id=goal.id, expected_revision=goal.revision,
        )

    def check_grant(self, ctx: GoalActionContext) -> None:
        if ctx.owner_store is None or self.expect.expected_owner is None:
            raise ValueError("Retry requires the executing owner's private goal authority.")

    def change(self, ctx: GoalActionContext) -> Goal:
        goal = ctx.require_goal()
        if not isinstance(goal.state, BlockedState):
            raise ValueError("The blocked goal changed; refresh its state.")
        store = ctx.owner_store
        assert store is not None
        generation = store.snapshot(goal.id)
        if generation is None:
            raise ValueError("Goal launch authority is missing; Retry cannot create a grant.")
        generation.lifecycle.authorize_retry(store, generation, uuid4().hex)
        return replace(goal, state=ActiveGoal(), revision=goal.revision + 1)
