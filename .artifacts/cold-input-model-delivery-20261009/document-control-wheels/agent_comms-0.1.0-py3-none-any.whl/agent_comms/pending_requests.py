"""Typed request correlation shared by internal setting results."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from .sealed import Sealed

@dataclass
class PendingRequest:
    future: asyncio.Future[Any]
    request: Any = None


class PendingRequests(Sealed):
    """One future per nominal result family and request identity."""

    def __init__(self) -> None:
        self._pending: dict[tuple[type, str], PendingRequest] = {}

    def add(
        self, result_type: type, request_id: str, *, request: Any = None
    ) -> asyncio.Future[Any]:
        key = (result_type, request_id)
        if key in self._pending:
            raise ValueError(f"Request already pending: {request_id}")
        future = asyncio.get_running_loop().create_future()
        self._pending[key] = PendingRequest(future, request)
        return future

    def discard(self, result_type: type, request_id: str) -> None:
        self._pending.pop((result_type, request_id), None)

    def take(self, result_type: type, request_id: str, value: Any) -> Any:
        """Resolve a transport result and return its originating command, once."""
        pending = self._pending.pop((result_type, request_id), None)
        if pending is None:
            return None
        if not pending.future.done():
            pending.future.set_result(value)
        return pending.request

    def cancel_all(self) -> None:
        for pending in self._pending.values():
            pending.future.cancel()
        self._pending.clear()

    def take_anonymous(self, result_type: type, value: Any) -> Any:
        for (owner, identity), pending in self._pending.items():
            if owner is result_type and pending.request.id is None:
                return self.take(owner, identity, value)
        return None
