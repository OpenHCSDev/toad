"""Input forwarding owns pending native IDs and never replays written inputs."""

from __future__ import annotations

import asyncio
import secrets
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from . import agent_events as events
from . import pi_commands as commands
from . import turn_failure as failures

if TYPE_CHECKING:
    from .backend import TurnSession
    from .pi_events import MessageStart, Response


@dataclass(frozen=True)
class ForwardedInput:
    original: str | dict[str, Any]
    public_id: str | None
    selected: list[str]


@dataclass
class InputForwarding:
    queue: asyncio.Queue[str | dict[str, Any]] | None = None
    pending: list[tuple[str | None, str, str | dict[str, Any], str]] = field(default_factory=list)
    accepted: set[str] = field(default_factory=set)
    changed: asyncio.Event = field(default_factory=asyncio.Event)
    generation: int = 0
    started: bool = False
    uncertain: bool = False

    @property
    def permits_admission(self) -> bool:
        """Only confirmed input delivery permits a fresh native interaction."""
        return not self.uncertain

    def can_forward(self, writer):
        return self.queue is not None and writer is not None

    @property
    def unresolved(self) -> bool:
        return bool(self.pending) or (self.queue is not None and not self.queue.empty())

    @property
    def settled(self) -> bool:
        return not self.uncertain and not self.unresolved

    def acknowledge(self, response: Response) -> None:
        if response.success is True and any(item[0] == response.id for item in self.pending):
            self.accepted.add(response.id)
        self.changed.set()

    async def forward(self, session: TurnSession) -> None:
        while True:
            message = await self.queue.get()
            original = dict(message) if isinstance(message, dict) else message
            wire = (
                dict(original)
                if isinstance(original, dict)
                else {"type": "prompt", "message": original, "streamingBehavior": "steer"}
            )
            forwarded = ForwardedInput(
                original, wire.pop("_input_id", None), wire.pop("_input_ids", [])
            )
            try:
                command = commands.PiCommand.from_wire(wire)
            except (ValueError, TypeError) as error:

                session.output.record_failure(
                    failures.PromptSendFailed(f"Invalid queued Pi command: {error}")
                )
                await session.native.proc.stop()
                return
            if not await command.steer(session, forwarded):
                return

    async def interrupt(self, session: TurnSession, forwarded: ForwardedInput) -> bool:

        while True:
            self.changed.clear()
            candidates = [item for item in self.pending if item[0] in forwarded.selected]
            if not candidates or all(item[0] in self.accepted for item in candidates):
                break
            await self.changed.wait()
        if not candidates:
            return True
        public_id, sent_text, _, native_id = candidates[0]
        from .backend import _maintenance_send_boundary

        boundary = _maintenance_send_boundary(
            session.startup.root,
            session.interrupt_boundary,
            public_id,
            native_id,
            sent_text,
        )
        async with boundary as authorized:
            if authorized:
                session.stdin.write(
                    session.native.reader.encode(
                        commands.InterruptSteering(input_ids=[item[3] for item in candidates])
                    )
                )
        if not authorized:
            self.uncertain = True
            session.output.final_assistant_stop = False
            session.output.record_failure(
                failures.AuthorityChanged("Input authority changed before immediate steering.")
            )
            await session.native.proc.stop()
            return False
        await session.stdin.drain()
        return True

    async def send_prompt(
        self, command: commands.Prompt, session: TurnSession, forwarded: ForwardedInput
    ) -> bool:
        from .backend import _maintenance_send_boundary

        public_id = forwarded.public_id or f"agent-comms-steer-{uuid4().hex}"
        native_id = secrets.token_hex(16)
        text = command.message
        if not session.require_input_id and isinstance(forwarded.original, str):
            text = f"[agent-comms input-id: {public_id}]\n{forwarded.original}"
        command = replace(command, id=public_id, input_id=native_id, message=text)
        self.pending.append((public_id, text, forwarded.original, native_id))
        boundary = _maintenance_send_boundary(
            session.startup.root,
            session.send_boundary,
            public_id,
            native_id,
            text,
        )
        async with boundary as authorized:
            if authorized:
                if command.images:
                    session.output.sensitive = True
                self.generation += 1
                session.stdin.write(session.native.reader.encode(command))
        if authorized:
            await session.stdin.drain()
            return True
        if authorized is False:
            self.uncertain = True
            session.output.final_assistant_stop = False
            session.output.record_failure(
                failures.AuthorityChanged("Input authority changed before Pi prompt send.")
            )
            await session.native.proc.stop()
            return False
        # None means never sent; preserve the owner's UNKNOWN, not a replay.
        self.pending[:] = [item for item in self.pending if item[3] != native_id]
        session.rejected_commands.append(events.InputRefused(id=public_id))
        session.rejected_signal.set()
        return True

    def mark_started(self, session: TurnSession, payload: MessageStart) -> tuple[bool, str | None]:
        message = payload.message
        if not message.user:
            return False, None
        text = message.text
        native_id = message.input_id
        for index, (input_id, queued_text, _, expected_native_id) in enumerate(self.pending):
            if (
                (session.require_input_id or input_id in self.accepted)
                and text == queued_text
                and (not session.require_input_id or native_id == expected_native_id)
            ):
                if not session.notify_input_started(input_id, expected_native_id, queued_text):
                    return (False, None)
                self.accepted.discard(input_id)
                self.pending.pop(index)
                self.started = True
                return (True, input_id)
        return (False, None)
