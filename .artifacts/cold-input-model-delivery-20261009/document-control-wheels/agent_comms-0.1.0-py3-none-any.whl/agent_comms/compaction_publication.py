"""Deliver already-durable compaction metadata to its existing local ACP owner only.

No bus recipient is inferred, no summary is sent, and uncertain local delivery
remains pending under the same exact native commit ID for safe deduplication.
"""

from __future__ import annotations

import asyncio
import json
import os
from typing import Any
from functools import partial
from .coordinator import Coordination

from acp.schema import AgentMessageChunk, TextContentBlock

from .acp_extension import CompactionPublishedUpdate, encode_updates
from .compaction_journal import CompactionJournal
from .compaction_publication_lease import publication_identity_fence
from .compaction_states import CompactionPublishedMetadata
from .errors import RelationViolationError, UnregisteredThreadError
from .field_codec import FieldCodec

# A stalled local client must not indefinitely pin the wire's owner-identity
# fence. wait_for joins cancellation of its transport coroutine before the
# lease is released; an uncooperative coroutine keeps the fence (fail closed).
LOCAL_HANDOFF_TIMEOUT_SECONDS = 3.0


async def publish_pending_local(agent: Any, session_id: str, thread_name: str) -> int:
    """Project up to 32 metadata rows; return only the number locally observed."""
    runtime = agent._runtime
    if agent.sessions.client is None and not runtime.clients.get(session_id):
        return 0  # No consumer: leave every row durably pending.
    path = agent._comms.root / "compaction-commits.sqlite3"
    if not path.exists() and not path.is_symlink():
        return 0
    projected = 0
    # Separate short-lived OS fence, NOT the registry/wire lock. Identity
    # mutations fail promptly while a local client handoff is in flight.
    # Cancellation releases the kernel fence; the row stays pending unless
    # its exact mark already COMMITted (reconcile rather than infer rollback).
    with publication_identity_fence(agent._comms.root, nonblocking=True):
        try:
            owner, owner_generation = await Coordination.run_worker(partial(
                agent._comms.registry.live_owner_with_generation, thread_name,
            ))
        except (RelationViolationError, UnregisteredThreadError):
            return 0
        if (
            owner.pid != os.getpid()
            or not owner.session_file
            or agent.sessions.require(session_id) != owner.name
        ):
            return 0
        identity = (
            owner.name,
            owner.created_at,
            owner.pid,
            owner_generation,
            owner.session_file,
            owner.worktree,
        )
        journal = CompactionJournal(path)
        client = agent.sessions.client
        sockets = frozenset(runtime.clients.get(session_id, ()))
        pending = await Coordination.run_worker(partial(journal.publications.pending, owner.session_file))
        for item in pending:
            # Recheck under the handoff fence; an owner epoch may change even
            # without a session rebind. No old row crosses that boundary.
            try:
                current, current_owner_generation = await Coordination.run_worker(partial(
                    agent._comms.registry.live_owner_with_generation, thread_name,
                ))
            except (RelationViolationError, UnregisteredThreadError):
                break
            if (
                (
                    current.name,
                    current.created_at,
                    current.pid,
                    current_owner_generation,
                    current.session_file,
                    current.worktree,
                )
                != identity
                or agent.sessions.require(session_id) != owner.name
                or agent.sessions.client is not client
                or not runtime.clients.get(session_id, set()).issubset(sockets)
            ):
                break
            # Only exact outbox metadata, never intent/summary/recipient.
            metadata = FieldCodec.decode(
                CompactionPublishedMetadata, json.loads(item.metadata_json)
            )
            try:
                delivered = await asyncio.wait_for(
                    runtime.session_update(
                        session_id=session_id,
                        update=AgentMessageChunk(
                            session_update="agent_message_chunk",
                            content=TextContentBlock(type="text", text=""),
                            field_meta=encode_updates(CompactionPublishedUpdate(metadata)),
                        ),
                        _expected_client=client,
                        _expected_thread=owner.name,
                        _expected_sockets=sockets,
                    ),
                    timeout=LOCAL_HANDOFF_TIMEOUT_SECONDS,
                )
            except TimeoutError:
                # wait_for has cancelled and joined this local transport task.
                # A partial/uncertain delivery is NOT a native abort or ACK.
                break
            if not delivered:
                # A client-only rebind after the outer check, or no surviving
                # socket transport, does not mark this exact row observed.
                break
            try:
                current, current_owner_generation = await Coordination.run_worker(partial(
                    agent._comms.registry.live_owner_with_generation, thread_name,
                ))
            except (RelationViolationError, UnregisteredThreadError):
                break
            if (
                (
                    current.name,
                    current.created_at,
                    current.pid,
                    current_owner_generation,
                    current.session_file,
                    current.worktree,
                )
                != identity
                or agent.sessions.require(session_id) != owner.name
                or agent.sessions.client is not client
                or not runtime.clients.get(session_id, set()).issubset(sockets)
                or (client is None and not runtime.clients.get(session_id))
            ):
                # No ACK after owner/client change or all socket sends failed.
                break
            await Coordination.run_worker(partial(journal.publications.observe, item.commit_id, item.metadata_json))
            projected += 1
    return projected
