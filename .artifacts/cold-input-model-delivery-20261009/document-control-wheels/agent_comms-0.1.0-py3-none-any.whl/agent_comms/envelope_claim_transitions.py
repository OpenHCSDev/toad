"""Pure claim transitions for the single-authority bus envelope.

No bus send, file append, O_EXCL claim sidecar, write fence, or retry lives here.
A caller must serialize send and every claim-bearing read under the wire→bus
locks, admit only newline-complete rows after fsync of the opened bus file (and
its parent on creation), and quarantine/re-fsync a visible row after failed
fsync before any reader observes it. Parsed rows alone are NOT durable proof.
"""

from __future__ import annotations

import stat
from abc import ABC, abstractmethod
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Literal

from .errors import RelationViolationError
from .message_reference import MessageReference
from .field_codec import FieldCodec
from .thread_identity import GenerationCounter, TurnId


class ClaimTransitionError(ValueError):
    """An invalid request or unverified/corrupt projection input."""


class ClaimConflict(ClaimTransitionError):  # noqa: N818 - domain-specific losing result
    """A synchronous losing transition; never queue or retry it automatically."""

    def __init__(self, existing: ClaimOwner):
        self.existing = existing
        super().__init__(f"Resource already claimed by {existing.owner!r}")


@dataclass(frozen=True)
class FileClaimPath(ABC):
    """A caller's file operation owns which physical paths may be claimed."""

    resource: Path

    def __post_init__(self) -> None:
        if not isinstance(self.resource, Path):
            raise TypeError("File claim requires a parsed path")

    def normalized(self, root: Path) -> str:
        base = Path(root).absolute()
        try:
            physical_root = base.resolve(strict=True)
            if physical_root != base or not base.is_dir():
                raise ClaimTransitionError("Worktree must be a physical existing directory.")
            requested = self.resource
            if ".." in requested.parts:
                raise ClaimTransitionError("Parent traversal is not a resource identifier.")
            candidate = requested if requested.is_absolute() else base / requested
            resolved = candidate.resolve(strict=False)
            if resolved != candidate:
                raise ClaimTransitionError("Symlink aliases are not supported.")
            relative = resolved.relative_to(physical_root)
            if not relative.parts:
                raise ClaimTransitionError("Worktree directories cannot be claimed.")
            self.validate_leaf(resolved)
        except (OSError, ValueError, RuntimeError) as error:
            if isinstance(error, ClaimTransitionError):
                raise
            raise ClaimTransitionError(
                "Resource is not a supported file inside the worktree."
            ) from error
        return str(resolved)

    @abstractmethod
    def validate_leaf(self, path: Path) -> None:
        """Validate the file state required by this operation."""

    @staticmethod
    def validate_regular(info) -> None:
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ClaimTransitionError("Only regular singly-linked files can be claimed.")


class ExistingFileClaim(FileClaimPath):
    def validate_leaf(self, path: Path) -> None:
        self.validate_regular(path.stat())


class WritableFileClaim(FileClaimPath):
    """Write may create a missing file, including missing parent directories."""

    def validate_leaf(self, path: Path) -> None:
        try:
            info = path.stat()
        except FileNotFoundError:
            return
        self.validate_regular(info)


def _text(value: object, label: str) -> str:
    if type(value) is not str or not value or len(value) > 4096:
        raise ClaimTransitionError(f"{label} must be a bounded nonempty string.")
    return value


def _generation(value: object) -> str:
    result = _text(value, "Generation")
    if len(result) != 32 or any(char not in "0123456789abcdef" for char in result):
        raise ClaimTransitionError("Generation must be a lowercase 128-bit hex value.")
    return result


def _resource(value: object) -> str:
    path = _text(value, "Resource")
    requested = Path(path)
    if (
        str(requested) != path
        or not requested.is_absolute()
        or requested.resolve(strict=False) != requested
    ):
        raise ClaimTransitionError("Resource must already be a canonical absolute path.")
    return path


@dataclass(frozen=True, slots=True)
class AssignmentBinding:
    """Selected claim revision and source, shared by its admission and SQL row."""

    assignment_id: str
    revision: int
    recipient_lookup: str
    source: MessageReference
    execution_id: str

    def __post_init__(self) -> None:
        _text(self.assignment_id, "Assignment ID")
        _text(self.recipient_lookup, "Recipient lookup")
        _text(self.source.message_id, "Source message ID")
        _text(self.execution_id, "Execution ID")
        if ":" in self.execution_id:
            raise ClaimTransitionError("Execution ID cannot contain a colon.")
        if FieldCodec.decode(int, self.source.seq) <= 0:
            raise ClaimTransitionError("Assignment source sequence must be positive.")
        if FieldCodec.decode(int, self.revision) <= 0:
            raise ClaimTransitionError("Assignment revision must be positive.")


@dataclass(frozen=True, slots=True)
class WakeAdmission:
    """A selected N/K execution bound into the durable resource-claim row."""

    wire_root_id: str
    source_seq: int
    source_message_id: str
    wake_assignment_id: str = field(metadata={"wire_name": "wake_claim_id"})
    wake_revision: int
    recipient_lookup: str
    execution_id: str
    operation_id: str
    owner_admission_generation: int
    turn_id: str
    participant_generation: int
    attempt_ordinal: int
    version: int = field(default=1, metadata={"wire_required": True})

    @property
    def binding(self) -> AssignmentBinding:
        return AssignmentBinding(
            self.wake_assignment_id,
            self.wake_revision,
            self.recipient_lookup,
            self.source,
            self.execution_id,
        )

    @property
    def source(self) -> MessageReference:
        return MessageReference(self.source_seq, self.source_message_id)

    def __post_init__(self) -> None:
        from .bus_publication import StableLookupText
        from .wire_metadata import WireRootIdText

        WireRootIdText.decode(self.wire_root_id)
        StableLookupText.decode(self.recipient_lookup)
        _generation(self.operation_id)
        try:
            FieldCodec.decode(Literal[1], self.version)
            AssignmentBinding(
                self.wake_assignment_id,
                self.wake_revision,
                self.recipient_lookup,
                self.source,
                self.execution_id,
            )
            GenerationCounter.require_positive(self.owner_admission_generation)
            GenerationCounter.require_positive(self.participant_generation)
            if FieldCodec.decode(int, self.attempt_ordinal) <= 0:
                raise ValueError("attempt ordinal must be positive")
        except ValueError as error:
            raise ClaimTransitionError("Wake admission version or revision is invalid.") from error
        TurnId.for_registration(self.turn_id)
        if (
            type(self.wake_assignment_id) is not str
            or not self.wake_assignment_id.startswith("cohort-v1:")
            or len(self.wake_assignment_id) != len("cohort-v1:") + 64
            or any(
                character not in "0123456789abcdef" for character in self.wake_assignment_id[10:]
            )
        ):
            raise ClaimTransitionError("Wake claim ID is invalid.")


@dataclass(frozen=True, slots=True)
class ClaimRelease:
    resource: str
    generation: str

    def __post_init__(self) -> None:
        _resource(self.resource)
        _generation(self.generation)


@dataclass(frozen=True, slots=True)
class ClaimTransition:
    """Claims and releases in ONE future message row, never independent writes."""

    owner: str
    incarnation: str
    seq: int
    message_id: str
    claims: tuple[str, ...] = field(default=(), metadata={"wire_required": True})
    releases: tuple[ClaimRelease, ...] = field(default=(), metadata={"wire_required": True})
    generation: str | None = field(default=None, metadata={"wire_required": True})
    admission: WakeAdmission | None = field(
        default=None, metadata={"wire_omit_default": True, "wire_nonnull": True}
    )

    def __post_init__(self) -> None:
        _text(self.owner, "Owner")
        _text(self.incarnation, "Incarnation")
        _text(self.message_id, "Message ID")
        if type(self.seq) is not int or self.seq <= 0:
            raise ClaimTransitionError("Sequence must be a positive exact integer.")
        if type(self.claims) is not tuple or type(self.releases) is not tuple:
            raise ClaimTransitionError("Claims and releases must be tuples.")
        if not self.claims and not self.releases:
            raise ClaimTransitionError("Empty claim transitions are not meaningful.")
        if any(type(release) is not ClaimRelease for release in self.releases):
            raise ClaimTransitionError("Releases must carry exact generation records.")
        resources = [*self.claims, *(release.resource for release in self.releases)]
        for resource in resources:
            _resource(resource)
        if len(set(resources)) != len(resources):
            raise ClaimTransitionError("Duplicate or overlapping resources are not supported.")
        if self.claims:
            _generation(self.generation)
        elif self.generation is not None:
            raise ClaimTransitionError("A release-only envelope cannot mint a generation.")
        if self.admission is not None and (
            type(self.admission) is not WakeAdmission or not self.claims or self.releases
        ):
            raise ClaimTransitionError("Wake admission requires a claim-only transition.")


@dataclass(frozen=True, slots=True)
class ClaimOwner:
    resource: str
    owner: str
    incarnation: str
    generation: str
    seq: int
    message_id: str
    admission: WakeAdmission | None = None

    def __post_init__(self) -> None:
        _resource(self.resource)
        _text(self.owner, "Owner")
        _text(self.incarnation, "Incarnation")
        _generation(self.generation)
        _text(self.message_id, "Message ID")
        if type(self.seq) is not int or self.seq <= 0:
            raise ClaimTransitionError("Claim sequence must be a positive exact integer.")
        if self.admission is not None and type(self.admission) is not WakeAdmission:
            raise ClaimTransitionError("Claim owner requires a typed wake admission.")


@dataclass(frozen=True, slots=True)
class ClaimProjection(Mapping[str, ClaimOwner]):
    """Immutable sorted claim table plus the last processed envelope sequence."""

    last_seq: int = 0
    _claims: Mapping[str, ClaimOwner] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if type(self.last_seq) is not int or self.last_seq < 0:
            raise ClaimTransitionError("Projection sequence must be a nonnegative exact integer.")
        if not isinstance(self._claims, Mapping) or any(
            type(value) is not ClaimOwner or value.resource != key or value.seq > self.last_seq
            for key, value in self._claims.items()
        ):
            raise ClaimTransitionError("Previous projection is malformed.")
        object.__setattr__(self, "_claims", MappingProxyType(dict(sorted(self._claims.items()))))

    def __getitem__(self, key: str) -> ClaimOwner:
        return self._claims[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._claims)

    def __len__(self) -> int:
        return len(self._claims)


def apply_transition(previous: ClaimProjection, transition: ClaimTransition) -> ClaimProjection:
    """All-or-nothing immutable projection from caller-verified durable envelopes.

    The caller MUST hold the wire→bus locks and verify bus fsync/newline and
    outer sender/sequence/message identity and unique registered creation
    incarnations. Neither this method nor a parser can determine whether an
    observed row was actually durable or whether two names are distinct owners.
    """
    if type(previous) is not ClaimProjection or type(transition) is not ClaimTransition:
        raise ClaimTransitionError("Only typed claim projections/transitions are accepted.")
    if transition.seq <= previous.last_seq:
        raise ClaimTransitionError("Claim sequence must increase.")
    next_state = dict(previous)
    for release in transition.releases:
        current = next_state.get(release.resource)
        if current is None:
            raise ClaimTransitionError("Cannot release a resource without a live claim.")
        # The envelope owner is the sender's name at publication time. Renaming
        # preserves the owner's incarnation, but must not strand an older claim
        # whose envelope recorded a previous name. The generation still fences
        # release after another owner has acquired the same resource.
        if (current.incarnation, current.generation) != (
            transition.incarnation,
            release.generation,
        ):
            raise ClaimTransitionError("Only the exact owner incarnation/generation may release.")
    for resource in transition.claims:
        if existing := next_state.get(resource):
            raise ClaimConflict(existing)
    for release in transition.releases:
        del next_state[release.resource]
    for resource in transition.claims:
        assert transition.generation is not None
        next_state[resource] = ClaimOwner(
            resource,
            transition.owner,
            transition.incarnation,
            transition.generation,
            transition.seq,
            transition.message_id,
            transition.admission,
        )
    return ClaimProjection(transition.seq, next_state)


def project_verified_transitions(rows: Iterable[ClaimTransition]) -> ClaimProjection:
    """Replay ONLY rows whose complete-line durability was verified by the caller.

    Do not pass raw JSONL or accept a claimed `fsynced` boolean as proof.
    The future guarded bus reader must supply *all* claim rows in increasing
    sequence, including release-only rows after the last live claim.
    """
    projection = ClaimProjection()
    for transition in rows:
        projection = apply_transition(projection, transition)
    return projection


def _release_resource(worktree: Path, path: str | Path) -> str:
    """Identify a prior canonical claim even if its original file was deleted."""
    physical_root = worktree.resolve(strict=True)
    raw = path if isinstance(path, str) else str(path)
    supplied = Path(raw)
    if str(supplied) != raw:
        raise RelationViolationError("Claim release requires canonical spelling.")
    candidate = supplied if supplied.is_absolute() else physical_root / supplied
    if ".." in candidate.parts:
        raise RelationViolationError("Claim release cannot traverse parent directories.")
    try:
        candidate.relative_to(physical_root)
    except ValueError as error:
        raise RelationViolationError("Claim release is outside the owner's worktree.") from error
    return str(candidate)
