"""Viewport-owned lifetimes for reconstructible document presentation.

The document keeps its source and native measured extent. Descendant widgets,
their message pumps, subscriptions and render caches have a shorter lifetime.
The window owns admission; documents implement their own retirement/restoration.
"""

from contextlib import AsyncExitStack, ExitStack, asynccontextmanager, contextmanager
from collections.abc import Awaitable, Callable, Coroutine
from collections import OrderedDict
from functools import partial
from weakref import WeakSet, ref
from time import monotonic
from dataclasses import dataclass, replace
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING
from textual.strip import Strip
from toad.rich_preparation import PreparedPaintSource, PreparedRichContent
from toad.work_preparation import retained_bytes
import asyncio
from toad.widgets.presentation_window import (
    DirectionalPreparation, PreparationDemand, PresentationBudget,
)

from textual.widget import Widget
from textual.visual import Visual
from textual.walk import walk_depth_first
from textual._measurement import INDEPENDENT_HEIGHT, NATIVE_WIDGET_HEIGHT, height_dependency
from textual.geometry import Size
from textual._paint_state import PaintState
from textual.worker import WorkerCancelled, NoActiveWorker, get_current_worker
from textual.worker import Worker
from textual.await_complete import AwaitComplete

if TYPE_CHECKING:
    from textual.document._paint import DocumentPaint
    from toad.markdown_preparation import PreparedMarkdown


class ViewportBody:
    """Nominal contract implemented by source-owning document widgets."""

    @property
    def body_dormant(self) -> bool:
        raise NotImplementedError

    @property
    def body_ready(self) -> bool:
        raise NotImplementedError

    @property
    def body_requires_geometry(self) -> bool:
        raise NotImplementedError

    @property
    def body_retained_paint_ready(self) -> bool:
        """The body supplies complete pixels without reading mutable children."""
        raise NotImplementedError

    def body_geometry_targets(self) -> tuple[Widget, ...]:
        raise NotImplementedError

    def body_preparation_targets(self) -> tuple["ViewportBody", ...]:
        """Original resources that supply this body's text, not its controls."""
        raise NotImplementedError

    @property
    def body_capture_pending(self) -> bool:
        raise NotImplementedError

    def require_native_body(self) -> None:
        """Visible or interactive demand ends an unfinished retirement."""
        raise NotImplementedError

    def retire_body(self) -> Coroutine[None, None, bool]:
        raise NotImplementedError

    async def restore_body(self) -> bool:
        raise NotImplementedError

    async def prepare_visible_source(self) -> bool:
        """Admit source parts through this body's existing viewport worker."""
        return False

    @property
    def has_newer_source(self) -> bool:
        """Whether this body's mounted edge precedes its original source tail."""
        return False

    @property
    def retained_source_bytes(self) -> int:
        return 0

    @property
    def retained_paint_bytes(self) -> int:
        return 0

    def release_paint(self) -> None:
        """Release a prepared paint resource at working-set eviction."""

    def retain_paint(self) -> None:
        """Admit this body's paint through its original resource lifetime."""
        raise NotImplementedError

    @property
    def measured_rows(self) -> int:
        raise NotImplementedError

    @property
    def retained_widget_count(self) -> int:
        raise NotImplementedError

    @property
    def materialized_widget_count(self) -> int:
        """Current native custody, including children still awaiting removal."""
        return 1 + self.descendant_count


@dataclass(frozen=True)
class BodyMeasurement(ABC):
    """One body's extent, native custody and prepared paint resource."""

    capture_pending = False

    @property
    @abstractmethod
    def width(self) -> int: ...

    @property
    @abstractmethod
    def rows(self) -> int: ...

    @property
    @abstractmethod
    def widgets(self) -> int: ...

    @property
    @abstractmethod
    def dormant(self) -> bool: ...

    @abstractmethod
    def ready(self, body) -> bool: ...

    @abstractmethod
    def cost(self, body) -> int: ...

    @property
    def paint_bytes(self) -> int:
        return 0

    @property
    def document_paint(self):
        return None

    @property
    def document_resource(self):
        return None

    @property
    def published_document_paint(self):
        """Intrinsic pixels supplied by this role, not merely retained by it."""
        return None

    def source_blocks(self, body):
        return None

    @staticmethod
    def same_source_block(left, right):
        return (left.source_index == right.source_index
                and left.document.same_source(right.document))

    def source_member(self, body, source):
        members = self.source_blocks(body)
        return (None if members is None else
                next((member for member in members if self.same_source_block(member, source)), None))

    def source_regions(self, body):
        return ()

    def source_visible_region(self, body, source):
        return None

    def export_source(self, body, source):
        return None

    def scene_roots(self, body):
        return None

    @abstractmethod
    def height(self, body, width, measure) -> int: ...

    def allocated(self, width):
        """Borrow native content width without replacing publication custody."""
        return self

    def content_width(self, body, measure) -> int:
        """Retained resources supply extent without measuring scene children."""
        return self.width

    @abstractmethod
    def render(self, body, crop, render_live) -> list[Strip]: ...

    @abstractmethod
    async def restore(self, body) -> None: ...

    def request_preparation(self, body):
        """Admit detached preparation without waiting on a widget's input FIFO."""
        if self.dormant and self.width > 0 and not self.ready(body):
            self.start_materialization(body, exit_on_error=True)

    def invalidated(self):
        return MeasuredBody(self.width, self.rows, self.widgets)

    async def materialize(self, body):
        await self.start_materialization(body).materialize(body)

    def start_materialization(self, body, work=None, *, exit_on_error=False):
        publication = AwaitComplete(self.before_publication())
        paint = AwaitComplete(self.prepare_publication(body))

        async def materialize():
            try:
                # Identity guards prevent an old commit; joining its actual
                # worker also prevents old native writes after the new commit.
                await publication
                [prepared] = await paint
                if prepared is not self:
                    # A pending predecessor's unchanged resource is already
                    # in this chain, including capture/width/style updates
                    # made while we joined it. Only a new capture replaces it.
                    # Width is the body's content measurement. An offscreen
                    # widget's last committed outer size is not a new demand.
                    # Genuine measurement/resize hooks have already updated
                    # this original resource while byte preparation awaited.
                    if prepared.width != body._body_measurement.width:
                        prepared = prepared.invalidated()
                    body._update_body_measurement(body._body_measurement.publication_prepared(worker, prepared, self))
                result = await (body.materialize_native_body() if work is None else work())
                # Native membership is committed before nested source workers
                # finish. Join their original publications here, after the
                # source operation released its window mutation fence, rather
                # than making a range's Mount wait on those same writers.
                for child in body.child_bodies():
                    for source in child.body_preparation_targets():
                        await source.restore_body()
                if body.is_attached:
                    body._update_body_measurement(
                        body._body_measurement.publication_finished(body, worker, result))
            except BaseException:
                body._update_body_measurement(
                    body._body_measurement.publication_failed(body, worker))
                raise

        worker = body.run_worker(materialize(), group="body-materialization", exit_on_error=exit_on_error)
        current = MaterializingBody(previous=self, worker=worker)
        body._update_body_measurement(current)
        return current

    async def before_publication(self) -> None:
        """Settled resources have no outstanding native writer to join."""

    def publishes_from(self, worker) -> bool:
        return False

    @asynccontextmanager
    async def batch(self, body, native_batch):
        async with native_batch():
            yield

    async def recompose(self, body, native_recompose):
        await body.publish_body(native_recompose)

    async def prepare_publication(self, body):
        return self

    def paint_ready(self, body) -> bool:
        """A measured extent or mutable native tree is not captured paint."""
        return False

    def source_empty(self, body, native_empty) -> bool:
        """Displayed source membership may outlive its scene descendants."""
        return native_empty

    def requires_geometry(self, body) -> bool:
        """Native content supplies descendant geometry; retained extent does not.

        Paint currentness governs publication, not which layout owns this
        resource. Colour or selection invalidation cannot revive retired
        controls or replace intrinsic document measurement with their layout.
        """
        return not self.dormant

    def geometry_targets(self, body):
        # Native ownership supplies layout when exposed; it is not demand to
        # place every hidden descendant. Reader restoration and capture own
        # the explicit offscreen requests passed to the native compositor.
        return ()

    def changes_geometry(self, body, previous):
        """Resource replacement changes layout only through its actual supply.

        Paint and writer identities still change independently. Native child
        membership and CSS retain their own layout invalidation; this resource
        supplies retained extent, descendant participation and explicit boxes.
        """
        return ((self.width, self.rows) != (previous.width, previous.rows)
                or self.requires_geometry(body) != previous.requires_geometry(body)
                or self.geometry_targets(body) != previous.geometry_targets(body))

    def preparation_targets(self, body):
        """A source/paint resource owns its original materialization worker."""
        return (body,)

    def capture_requested(self):
        return self

    def required(self):
        return self

    def publication_prepared(self, worker, paint, predecessor):
        return self

    def measured(self, width, rows):
        return self

    def get_selection(self, body, selection, select_live):
        return None

    def publication_finished(self, body, worker, result):
        """A settled resource does not own this worker's publication."""
        return self

    def publication_failed(self, body, worker):
        """A replaced publication cannot invalidate another resource."""
        return self

    def publication_aborted(self):
        """A failed writer cannot certify the native tree it partly changed."""
        return self.invalidated()

    def released(self):
        return self

    def admitted(self):
        return self

    def paint_cost(self, body):
        return self.paint_bytes

    def source_cost(self, body):
        return 0

    def release_paint(self, body):
        return self.released()

    def retain_paint(self, body):
        return self.admitted()

    def style_updated(self, body):
        return self

    def resized(self, size):
        return self

    async def retire(self, body):
        return False


@dataclass(frozen=True)
class MeasuredBody(BodyMeasurement):
    width: int = 0
    rows: int = 0
    widgets: int = 1

    @property
    def dormant(self):
        return True

    def ready(self, body):
        return False

    def cost(self, body):
        return self.widgets

    def height(self, body, width, measure):
        return self.rows

    def allocated(self, width):
        # The preceding extent survives while its current width prepares.
        return self if width == self.width else replace(self, width=width)

    def render(self, body, crop, render_live):
        # This state has extent but no pixels; the original frame owner waits
        # for reconstruction. It must not treat measurement as paint coverage.
        return render_live(crop)

    async def restore(self, body):
        await body.materialize_body()


@dataclass(frozen=True, kw_only=True)
class MeasuredSourceBody(MeasuredBody):
    """Committed source membership remains when its paint is released."""

    root_empty: bool

    def source_empty(self, body, native_empty):
        return self.root_empty

    def invalidated(self):
        return self


@dataclass(frozen=True)
class LiveBody(MeasuredBody):
    def allocated(self, width):
        # Native children supply both dimensions together through measured().
        return self

    def get_selection(self, body, selection, select_live):
        return select_live(selection) if self.ready(body) else None

    def released(self):
        return self.native_released()

    def capture_requested(self):
        return self.native_capturing()

    def native_live(self):
        return LiveBody(self.width, self.rows, self.widgets)

    def native_capturing(self):
        return CapturingBody(self.width, self.rows, self.widgets)

    def native_released(self):
        return ReleasedBody(self.width, self.rows, self.widgets)

    def capture_unavailable(self):
        return MeasuredBody(self.width, self.rows, self.widgets)

    def captured(self, *, widgets, content, resource_bytes, style_revision, paint_state,
                 root_empty, source_regions):
        return RenderedBody(self.width, self.rows, widgets, content=content,
                            resource_bytes=resource_bytes, style_revision=style_revision,
                            paint_state=paint_state, root_empty=root_empty)

    def capture_source_regions(self, body, placement, geometry):
        return ()

    def capture_cost(self, content, source_regions):
        return retained_bytes(content)

    def source_retired(self, body):
        return MeasuredSourceBody(self.width, self.rows, self.widgets, root_empty=body.is_empty)

    def publication_aborted(self):
        return self.capture_unavailable()

    def prepare_publication(self, body):
        # Borrow the original published scene synchronously, before a writer
        # or its byte measurement can change the native tree.
        return body.capture_native_paint(self)

    def invalidated(self):
        # The original native tree still carries its pixels. Replace the
        # captured lifetime so an in-flight retirement cannot publish old rows.
        return replace(self)

    @property
    def dormant(self):
        return False

    def ready(self, body):
        return body.native_body_ready()

    def cost(self, body):
        return body.materialized_widget_count

    def height(self, body, width, measure):
        return measure()

    def content_width(self, body, measure):
        return measure()

    def measured(self, width, rows):
        return self if (width, rows) == (self.width, self.rows) else replace(self, width=width, rows=rows)

    def render(self, body, crop, render_live):
        return render_live(crop)

    async def restore(self, body):
        return

    async def materialize(self, body):
        return

    def retire(self, body):
        return body.retire_native_body(self)


@dataclass(frozen=True)
class ChildBody(LiveBody):
    """A native range arranges child resources; it doesn't own their pixels.

    Source admission and headers belong to this container. Each document or
    disclosure owns its paint and native controls independently. Capturing
    those rows again at the container would erase their source/selection
    identity and force rebuilding the same document after every return.
    """

    async def prepare_publication(self, body):
        return self

    def paint_cost(self, body):
        return sum(child.retained_paint_bytes for child in body.child_bodies())

    def source_cost(self, body):
        return sum(child.retained_source_bytes for child in body.child_bodies())

    def release_paint(self, body):
        for child in body.child_bodies():
            child.release_paint()
        return self

    def retain_paint(self, body):
        for child in body.child_bodies():
            child.retain_paint()
        return self

    def geometry_targets(self, body):
        return tuple(dict.fromkeys(target for child in body.child_bodies()
                                   for target in child.body_geometry_targets()))

    def preparation_targets(self, body):
        # The range stays live while its independent text resources retire.
        # Its own dormant flag cannot decide whether those rows need work.
        return tuple(target for child in body.child_bodies()
                     for target in child.body_preparation_targets())

    async def retire(self, body):
        # Children retain their own source, measurement and paint. Only an
        # actual scene owner may prune its reconstructible native controls.
        # Its original retirement checks reacquire exposure and source custody.
        retired = False
        for child in body.child_bodies():
            if child.is_attached and not child._closing and not child.body_dormant:
                retired = await child.retire_body() or retired
        return retired


@dataclass(frozen=True)
class CapturingBody(LiveBody):
    """A live body acquiring complete native rows for its own retirement.

    Visible paint requires only exposed paragraphs. Complete capture needs
    every admitted paragraph's assigned box and committed prepared resource.
    Their original Resize/ExtentReady messages finish this acquisition; no
    viewport worker waits on background preparation.
    """

    capture_pending = True

    def capture_requested(self):
        return self

    def geometry_targets(self, body):
        return (body, *walk_depth_first(body, PreparedPaintSource, with_root=False))

    def required(self):
        return self.native_live()


@dataclass(frozen=True)
class ReleasedBody(LiveBody):
    """Unadmitted native children awaiting their original bounded retirement.

    Their last measured extent remains useful; preparing complete pixels only
    to discard them is not required. Visible demand or renewed paint admission
    revokes this release before the original source custody can prune children.
    """

    def released(self):
        return self

    def required(self):
        return self.native_live()

    def admitted(self):
        return self.required()

    def prepare_publication(self, body):
        return self.capture_unavailable().prepare_publication(body)

    def retire(self, body):
        return body.release_native_body(self)


@dataclass(frozen=True, kw_only=True)
class MaterializingBody(BodyMeasurement):
    """One native writer borrowing the body's preceding paint resource.

    Dimensions and retained bytes belong to that resource. The worker owns
    publication and interaction; a pending writer is never a second extent.
    """

    previous: BodyMeasurement
    worker: Worker

    @property
    def width(self):
        return self.previous.width

    @property
    def rows(self):
        return self.previous.rows

    @property
    def widgets(self):
        return self.previous.widgets

    @property
    def dormant(self):
        return True

    def ready(self, body):
        return self.paint_ready(body)

    def paint_ready(self, body):
        return self.previous.paint_ready(body)

    def source_empty(self, body, native_empty):
        return self.previous.source_empty(body, native_empty)

    def requires_geometry(self, body):
        # The writer borrows its original resource until publication commits.
        # A new paint demand doesn't change that resource's geometry supplier.
        return self.previous.requires_geometry(body)

    def geometry_targets(self, body):
        return self.previous.geometry_targets(body)

    def publication_prepared(self, worker, paint, predecessor):
        # A later writer may already own this body while joining our worker.
        # Update the resource in that original chain, never its writer identity.
        if self.worker is worker:
            # Width/style/selection and byte eviction may have changed custody
            # while capture measured its rows. Do not revive that old resource.
            return self._updated(paint) if self.previous is predecessor else self
        previous = self.previous.publication_prepared(worker, paint, predecessor)
        return self._updated(previous)

    def cost(self, body):
        return max(self.previous.cost(body), body.materialized_widget_count)

    @property
    def paint_bytes(self):
        return self.previous.paint_bytes

    def paint_cost(self, body):
        return self.previous.paint_cost(body)

    def source_cost(self, body):
        return self.previous.source_cost(body)

    def release_paint(self, body):
        return self._updated(self.previous.release_paint(body))

    def retain_paint(self, body):
        return self._updated(self.previous.retain_paint(body))

    @property
    def document_paint(self):
        return self.previous.document_paint

    @property
    def document_resource(self):
        return self.previous.document_resource

    @property
    def published_document_paint(self):
        return self.previous.published_document_paint

    def source_blocks(self, body):
        return self.previous.source_blocks(body)

    def source_regions(self, body):
        return self.previous.source_regions(body)

    def source_visible_region(self, body, source):
        return self.previous.source_visible_region(body, source)

    def export_source(self, body, source):
        return self.previous.export_source(body, source)

    def height(self, body, width, measure):
        return self.previous.height(body, width, measure)

    def allocated(self, width):
        return self._updated(self.previous.allocated(width))

    def content_width(self, body, measure):
        return self.previous.content_width(body, measure)

    def render(self, body, crop, render_live):
        return self.previous.render(body, crop, render_live)

    def get_selection(self, body, selection, select_live):
        return self.previous.get_selection(body, selection, select_live)

    def _updated(self, previous):
        return self if previous is self.previous else replace(self, previous=previous)

    def measured(self, width, rows):
        return self._updated(self.previous.measured(width, rows))

    def invalidated(self):
        return self._updated(self.previous.invalidated())

    def released(self):
        return self._updated(self.previous.released())

    def admitted(self):
        return self._updated(self.previous.admitted())

    def style_updated(self, body):
        # Descendant writes belong to the new source, not the old captured
        # rows. Actual inherited paint/width changes still retire those rows.
        return self._updated(self.previous.style_updated(body))

    def resized(self, size):
        return self._updated(self.previous.resized(size))

    async def restore(self, body):
        await self.before_publication()

    def request_preparation(self, body):
        # This resource already owns its actual writer. Layout, style and
        # selection can invalidate its input, but cannot start a second writer
        # or occupy the widget's message pump while the first one finishes.
        return

    async def materialize(self, body):
        await self.before_publication()

    def before_publication(self) -> Awaitable[None]:
        # The next writer borrows only the worker, not a coroutine retaining
        # an old paint snapshot after the body's LRU has released it.
        return self.worker.wait()

    def publishes_from(self, worker) -> bool:
        return self.worker is worker or self.previous.publishes_from(worker)

    @property
    def publishing(self) -> bool:
        try:
            return self.publishes_from(get_current_worker())
        except NoActiveWorker:
            return False

    @asynccontextmanager
    async def batch(self, body, native_batch):
        # The original window gate checks current coverage on every frame;
        # width/style invalidation during this await cannot expose partial rows.
        from toad.screens.workspace import WorkspaceScreen

        if self.publishing and isinstance(body.screen, WorkspaceScreen):
            async with body.screen.viewport_presentation.batch(body, native_batch):
                yield
            return
        async with native_batch():
            yield

    async def recompose(self, body, native_recompose):
        if self.publishing:
            await native_recompose()
        else:
            await super().recompose(body, native_recompose)

    def publication_finished(self, body, worker, result):
        if self.worker is worker:
            if result is False:
                # A source owner refused its admission. Joining its worker
                # does not publish new native content or revive old controls.
                return self.previous
            if body._body_measurement is self:
                # Only the current writer exposes its newly committed native
                # tree. A newer writer still borrows the preceding pixels.
                if isinstance(result, BodyMeasurement):
                    return result
                return body.live_body_measurement(self.width, self.rows, self.widgets)
            return self.previous
        return self._updated(self.previous.publication_finished(body, worker, result))

    def publication_failed(self, body, worker):
        if self.worker is worker:
            # Later writers borrow this same predecessor too. None may inherit
            # a ready scene after its actual native writer failed midway.
            return self.previous.publication_aborted()
        return self._updated(self.previous.publication_failed(body, worker))


@dataclass(frozen=True, kw_only=True)
class RenderedBody(MeasuredSourceBody):
    content: PreparedRichContent
    resource_bytes: int
    style_revision: int
    paint_state: PaintState

    def invalidated(self):
        return MeasuredSourceBody(self.width, self.rows, self.widgets,
                                  root_empty=self.root_empty)

    @property
    def dormant(self):
        return True

    def ready(self, body):
        # Screen commits sizes only for its current layout/exposed widgets.
        # An offscreen widget's last committed size is not a new width demand.
        # Measurement and actual size commits invalidate this resource below.
        return (self.paint_ready(body) and body.native_body_ready()
                and self.style_revision == body._subtree_style_revision)

    def paint_ready(self, body):
        # Captured strips are immutable. Loading and changes to the new native
        # descendants do not change them; inherited effective paint does.
        return (body.is_mounted and not body._closing
                and self.paint_state.style_key == body.styles._cache_key
                and self.paint_state.same_paint(body._resolved_paint_state()))

    def style_updated(self, body):
        return self if self.ready(body) else self.invalidated()

    def resized(self, size):
        return self if size.width == self.content.width else self.invalidated()

    def cost(self, body):
        return body.materialized_widget_count

    @property
    def paint_bytes(self):
        return self.resource_bytes

    def height(self, body, width, measure):
        return self.rows

    def allocated(self, width):
        return self if width == self.width else self.invalidated().allocated(width)

    def render(self, body, crop, render_live):
        selection = body.text_selection
        return self.content.render_lines(
            crop, selection=selection,
            selection_style=body.selection_style if selection is not None else None)

    def get_selection(self, body, selection, select_live):
        return (selection.extract(self.content.text), '\n') if self.paint_ready(body) else None

    def released(self):
        return self.invalidated()

    async def restore(self, body):
        if not self.ready(body):
            body.invalidate_body()
            await body.materialize_body()


@dataclass(frozen=True, kw_only=True)
class DocumentSourceBody(BodyMeasurement):
    """The acquired source is shared by paint and native control roles."""

    source_resource: "PreparedMarkdown"

    def source_cost(self, body):
        return self.source_resource.retained_bytes

    @property
    def document_resource(self):
        return self

    def owns_document(self, body):
        current = body.get_current_document()
        document = self.source_resource.document
        return (body.is_attached and not body._closing and current is not None
                and document is not None and current.same_source(document))

    def interactive(self, body):
        measurement = body._body_measurement
        return LiveDocumentBody(measurement.width, measurement.rows,
                                body.materialized_widget_count, resource=self)

    def source_retired(self, width, rows, widgets, *, root_empty):
        # Source membership and native extent are the last committed answers.
        # Pixel disposal drops references, not the original resolved supplier.
        released = self.released()
        return replace(released, width=width, rows=rows, widgets=widgets, root_empty=root_empty)


@dataclass(frozen=True)
class MeasuredDocumentBody(DocumentSourceBody, MeasuredSourceBody):
    """Released pixels, retained source and its last committed extent."""


@dataclass(frozen=True)
class PreparedDocumentBody(DocumentSourceBody):
    """Worker-owned intrinsic paint, distinct from captured scene pixels."""

    paint: "DocumentPaint"
    resource_bytes: int

    @property
    def document_paint(self):
        return self.paint

    @property
    def published_document_paint(self):
        return self.paint

    def source_blocks(self, body):
        width = body._body_measurement.width + body.styles.gutter.width
        return (tuple(source for source in self.paint.roots if source.placement is not None)
                if self.owns_document(body) and self.paint.is_current(body, width,
                    admissions=body.document_admissions) else None)

    def source_regions(self, body):
        sources = self.source_blocks(body)
        geometry = body.screen._compositor._published_map.get(body)
        return (() if sources is None or geometry is None else
                tuple((source, source.placement.region.translate(geometry.region.offset))
                      for source in sources))

    def source_visible_region(self, body, source):
        member = self.source_member(body, source)
        geometry = body.screen._compositor.visible_widgets.get(body)
        if member is None or geometry is None:
            return None
        region, clip = geometry
        placement = member.placement
        return placement.region.intersection(placement.clip).translate(region.offset).intersection(clip)

    def export_source(self, body, source):
        from textual.strip import StripRenderable

        member = self.source_member(body, source)
        if member is None:
            return None
        region = member.placement.region.intersection(self.paint.size.region)
        return (region.size, StripRenderable(self.paint.render_lines(region), region.width)) if region else None

    @property
    def width(self):
        return self.paint.content_size.width

    @property
    def rows(self):
        return self.paint.content_size.height

    @property
    def widgets(self):
        return 1

    @property
    def dormant(self):
        return True

    def source_empty(self, body, native_empty):
        return self.paint.root_empty

    def ready(self, body):
        return (self.paint_ready(body) and self.paint.document is body.document
                and not body.loading)

    def paint_ready(self, body):
        # This is the actual publication participant's native admission. A
        # replacement source may borrow these rows, but cannot claim readiness.
        return (body.is_mounted and not body._closing
                and self.paint.is_current(body, self.paint.width,
                                          admissions=body.document_admissions))

    def cost(self, body):
        return body.materialized_widget_count

    @property
    def paint_bytes(self):
        return self.resource_bytes

    def height(self, body, width, measure):
        return self.rows

    def allocated(self, width):
        return self if width == self.width else self.invalidated(width)

    def render(self, body, crop, render_live):
        return self.paint.render_lines(crop)

    def get_selection(self, body, selection, select_live):
        # Pointer selection acquires original scene controls before native
        # targeting. Whole-document copy can borrow each original leaf owner.
        # Selection styling may still be preparing; it doesn't replace text.
        document = body.document
        if (document is None or not self.paint.document.same_source(document)
                or self.paint.presentation_key != document.presentation.key
                or not document.presentation.current_for(body, admissions=body.document_admissions)
                or selection.start is not None or selection.end is not None):
            return None
        parts = (leaf.selected_text(selection) for leaf in self.paint.leaves)
        text = "".join(value[0] + value[1] for value in parts if value is not None).rstrip("\n")
        return text, "\n"

    def style_updated(self, body):
        width = body._body_measurement.width + body.styles.gutter.width
        if width == self.paint.width and self.paint_ready(body):
            return self
        document = body.document
        if document is not None and self.paint.document.same_source(document):
            # Membership publication can rematch the host's :empty rules.
            # The worker already resolved those same source-dependent rules.
            # Reuse only after full acquired input equality, never by copying
            # the new participant's invalidation counter onto old pixels.
            document = document.with_presentation(body)
            selection = body.text_selection
            if self.paint.matches(
                document, width, root_selection=selection,
                selection_style=Visual.selection_style(body) if selection is not None else None,
                selecting=body.screen._selecting,
            ):
                body.document = document
                return PreparedDocumentBody(self.paint.with_presentation(
                    document, root_selection=self.paint.root_selection,
                    selection_style=self.paint.selection_style, selecting=self.paint.selecting,
                ), self.resource_bytes, source_resource=self.source_resource)
        return self.invalidated()

    def invalidated(self, width=None):
        return PendingDocumentBody(self.paint, self.resource_bytes,
                                   self.width if width is None else width,
                                   source_resource=self.source_resource)

    def resized(self, size):
        return (self if size.width == self.paint.width else
                self.invalidated(size.width - self.paint.gutter.width))

    def released(self):
        return MeasuredDocumentBody(self.width, self.rows, self.widgets,
                                    root_empty=self.paint.root_empty,
                                    source_resource=self.source_resource)

    async def restore(self, body):
        if not self.ready(body):
            await body.materialize_body()


@dataclass(frozen=True)
class PendingDocumentBody(PreparedDocumentBody):
    """Original document membership/extent awaiting new presentation paint."""

    requested_width: int

    @property
    def width(self):
        return self.requested_width

    def ready(self, body):
        return False

    def paint_ready(self, body):
        return False

    @property
    def published_document_paint(self):
        return None

    def source_blocks(self, body):
        return None

    def invalidated(self, width=None):
        return self if width is None or width == self.width else replace(self, requested_width=width)

    def render(self, body, crop, render_live):
        return render_live(crop)


@dataclass(frozen=True, kw_only=True)
class NativeDocumentBody(BodyMeasurement):
    """Native scene identity borrowing, not publishing, a document resource.

    The scene still owns geometry, leaf styling and partial selection. The
    intrinsic resource remains available for later exact-input preparation.
    Actual capture supplies native pixels before that scene changes or retires.
    """

    resource: DocumentSourceBody

    @property
    def document_resource(self):
        return self.resource

    @property
    def document_paint(self):
        return self.resource.document_paint

    @property
    def paint_bytes(self):
        return self.resource.paint_bytes + super().paint_bytes

    def source_cost(self, body):
        return self.resource.source_cost(body)

    def native_live(self):
        return LiveDocumentBody(self.width, self.rows, self.widgets, resource=self.resource)

    def native_capturing(self):
        return CapturingDocumentBody(self.width, self.rows, self.widgets, resource=self.resource)

    def native_released(self):
        return ReleasedDocumentBody(self.width, self.rows, self.widgets, resource=self.resource.released())

    def capture_unavailable(self):
        return self.resource.publication_aborted().allocated(self.width)

    def publication_aborted(self):
        # Native controls may be partly replaced. Source custody survives;
        # neither the failed live scene nor its invalid rows become ready paint.
        return self.capture_unavailable()

    def captured(self, *, widgets, content, resource_bytes, style_revision, paint_state,
                 root_empty, source_regions):
        return RenderedDocumentBody(
            self.width, self.rows, widgets, content=content, resource_bytes=resource_bytes,
            style_revision=style_revision, paint_state=paint_state, root_empty=root_empty,
            resource=self.resource, captured_sources=source_regions,
        )

    def capture_source_regions(self, body, placement, geometry):
        offset = placement.region.offset
        regions = []
        roots = self.scene_roots(body)
        if roots is None:
            raise RuntimeError("Native document capture lost its acquired source controls")
        for root in roots:
            source = root.source_block
            box = geometry.get(root)
            if box is None:
                raise RuntimeError("Native document capture omitted a displayed source block")
            regions.append((source, box.region.translate(-offset), box.clip.translate(-offset)))
        return tuple(regions)

    def capture_cost(self, content, source_regions):
        # This is the original preparation thread, not a UI graph walk. Charge
        # captured rows/geometry once, excluding the resource already retained.
        seen = set()
        retained_bytes(self.resource.source_resource, seen=seen)
        retained_bytes(self.resource.document_paint, seen=seen)
        return retained_bytes((content, source_regions), seen=seen)

    def source_retired(self, body):
        return self.resource.source_retired(self.width, self.rows, self.widgets, root_empty=body.is_empty)

    def invalidated(self):
        return replace(self, resource=self.resource.invalidated())

    def measured(self, width, rows):
        native = super().measured(width, rows)
        resource = native.resource.allocated(width)
        return native if resource is native.resource else replace(native, resource=resource)

    def style_updated(self, body):
        native = super().style_updated(body)
        if native is not self:
            return native
        resource = self.resource.style_updated(body)
        return self if resource is self.resource else replace(self, resource=resource)

    def resized(self, size):
        native = super().resized(size)
        if native is not self:
            return native
        resource = self.resource.resized(size)
        return self if resource is self.resource else replace(self, resource=resource)

    def scene_roots(self, body):
        from textual.widgets._markdown import MarkdownBlock

        if body._body_measurement.dormant or not self.ready(body) or not self.resource.owns_document(body):
            return None
        roots = tuple(child for child in body.displayed_children if isinstance(child, MarkdownBlock))
        if any(child.source_block is None for child in roots):
            raise RuntimeError("Native document controls lost their original source binding")
        return roots

    def scene_block(self, body, source):
        roots = self.scene_roots(body)
        return (None if roots is None else next((root for root in roots
                if self.same_source_block(root.source_block, source)), None))

    def source_blocks(self, body):
        roots = self.scene_roots(body)
        return None if roots is None else tuple(root.source_block for root in roots)

    def source_regions(self, body):
        roots = self.scene_roots(body)
        placements = body.screen._compositor._published_map
        return () if roots is None else tuple((root.source_block, box.region) for root in roots
                                             if (box := placements.get(root)) is not None)

    def source_visible_region(self, body, source):
        root = self.scene_block(body, source)
        geometry = body.screen._compositor.visible_widgets.get(root)
        return None if geometry is None else geometry[0].intersection(geometry[1])

    def export_source(self, body, source):
        from textual._compositor import Compositor

        root = self.scene_block(body, source)
        if root is None or root not in body.screen._compositor._published_map:
            return None
        compositor = Compositor()
        compositor.reflow(root, root.outer_size)
        return root.outer_size, compositor.render_full_update()


@dataclass(frozen=True)
class LiveDocumentBody(NativeDocumentBody, LiveBody):
    pass


@dataclass(frozen=True)
class CapturingDocumentBody(NativeDocumentBody, CapturingBody):
    pass


@dataclass(frozen=True)
class ReleasedDocumentBody(NativeDocumentBody, ReleasedBody):
    pass


@dataclass(frozen=True, kw_only=True)
class RenderedDocumentBody(NativeDocumentBody, RenderedBody):
    """Actual scene rows/boxes, independently retained intrinsic preparation."""

    captured_sources: tuple

    def invalidated(self):
        return self.capture_unavailable()

    def released(self):
        # Neither set of pixels survives byte eviction. The original acquired
        # source, and the captured scene's membership/extent, still do.
        return self.resource.source_retired(self.width, self.rows, self.widgets, root_empty=self.root_empty)

    def scene_roots(self, body):
        return None

    def source_blocks(self, body):
        return (tuple(source for source, _region, _clip in self.captured_sources)
                if self.resource.owns_document(body) and self.paint_ready(body) else None)

    def source_regions(self, body):
        geometry = body.screen._compositor._published_map.get(body)
        if geometry is None or self.source_blocks(body) is None:
            return ()
        return tuple((source, region.translate(geometry.region.offset))
                     for source, region, _clip in self.captured_sources)

    def source_visible_region(self, body, source):
        member = self.source_member(body, source)
        geometry = body.screen._compositor.visible_widgets.get(body)
        if geometry is None or member is None:
            return None
        placement = next((region, clip) for original, region, clip in self.captured_sources if original is member)
        region, clip = placement
        return region.intersection(clip).translate(geometry[0].offset).intersection(geometry[1])

    def export_source(self, body, source):
        from textual.strip import StripRenderable

        member = self.source_member(body, source)
        if member is None:
            return None
        region = next(region for original, region, _clip in self.captured_sources if original is member)
        region = region.intersection(Size(self.content.width, len(self.content.lines)).region)
        return (region.size, StripRenderable(self.content.render_lines(region), region.width)) if region else None


class MeasuredViewportBody(ViewportBody):
    """The body owns Live, Rendered and Measured behavior, not copied flags."""

    CACHE_SUBTREE_GEOMETRY = True

    def __init__(self, *args, **kwargs):
        self._body_measurement = LiveBody()
        self._body_viewport = None
        super().__init__(*args, **kwargs)

    def live_body_measurement(self, width=0, rows=0, widgets=1):
        """The declaration supplies the role of its committed native content."""
        return LiveBody(width, rows, widgets)

    def child_bodies(self):
        """Original DOM custody, stopping at each independent resource owner."""
        pending = list(reversed(self.children))
        while pending:
            child = pending.pop()
            if isinstance(child, ViewportBody):
                yield child
            else:
                pending.extend(reversed(child.children))

    @property
    def body_dormant(self):
        return self._body_measurement.dormant

    @property
    def is_empty(self):
        return self._body_measurement.source_empty(self, super().is_empty)

    @property
    def body_ready(self):
        return self._body_measurement.ready(self)

    @property
    def body_requires_geometry(self):
        return self._body_measurement.requires_geometry(self)

    @property
    def body_retained_paint_ready(self):
        return self._body_measurement.paint_ready(self)

    def body_geometry_targets(self):
        return self._body_measurement.geometry_targets(self)

    def body_preparation_targets(self):
        return self._body_measurement.preparation_targets(self)

    @property
    def document_admissions(self):
        """Borrow only the actual synchronous native paint acquisition.

        A standalone body and all asynchronous publications retain live checks.
        The window membership supplies this resource's original screen owner.
        """
        return (None if self._body_viewport is None else
                self._body_viewport.membership.presentation.document_admissions)

    @property
    def body_capture_pending(self):
        return self._body_measurement.capture_pending

    def require_native_body(self):
        self._update_body_measurement(self._body_measurement.required())

    @property
    @height_dependency(INDEPENDENT_HEIGHT)
    def is_container(self):
        # Native geometry, intrinsic document extent and captured rows are
        # supplied by their resource states. Readiness decides whether those
        # pixels can publish, never whether to traverse an old native subtree.
        return self.body_requires_geometry and super().is_container

    @property
    def _render_widget(self):
        return super()._render_widget if self.body_requires_geometry else self

    def native_body_ready(self):
        if not self.is_mounted or self._closing:
            return False
        # Frame coverage is the native published visible cohort. Hidden
        # descendants still require exact committed resources for capture,
        # but their preparation cannot hold an unrelated visible frame.
        visible = self.screen._compositor.visible_widgets
        return all(source.presentation_ready
                   for source in walk_depth_first(self, PreparedPaintSource, with_root=False)
                   if source in visible)

    @property
    def measured_rows(self):
        return self._body_measurement.rows

    @property
    def retained_widget_count(self):
        return self._body_measurement.cost(self)

    @property
    def retained_paint_bytes(self):
        return self._body_measurement.paint_cost(self)

    @property
    def retained_source_bytes(self):
        return self._body_measurement.source_cost(self)

    def release_paint(self):
        self._update_body_measurement(self._body_measurement.release_paint(self))

    def retain_paint(self):
        self._update_body_measurement(self._body_measurement.retain_paint(self))

    def invalidate_body(self):
        self._update_body_measurement(self._body_measurement.invalidated())

    def _update_body_measurement(self, measurement):
        if measurement is self._body_measurement:
            return
        previous = self._body_measurement
        empty = self.is_empty
        self._body_measurement = measurement
        if self.is_empty != empty:
            self.update_node_styles()
            # A membership pseudo can change the native admission even when
            # its stylesheet has no different rule values to notify about.
            self._body_measurement = self._body_measurement.style_updated(self)
        # Resource custody, paint and native geometry are independent changes.
        # Publish actual geometry supply before pruning, without arranging the
        # whole scene again for a paint invalidation or a new writer alone.
        self.refresh(layout=self._body_measurement.changes_geometry(self, previous))
        self.request_body_preparation()

    def request_body_preparation(self):
        """The window prepares its cohort; standalone bodies own their writer."""
        if not self.is_attached or self._closing or self._pruning:
            return
        if self._body_viewport is not None:
            self._body_viewport.request()
        else:
            self._body_measurement.request_preparation(self)

    def notify_style_update(self):
        super().notify_style_update()
        # Notification is not a rule mutation. Retained rows depend on the
        # original subtree rule epoch and inherited native paint values.
        self._update_body_measurement(self._body_measurement.style_updated(self))

    def selection_updated(self, selection):
        super().selection_updated(selection)
        # Selection belongs to Screen. The resource derives whether its paint
        # changed; the same preparation owner handles style, size and selection.
        self._update_body_measurement(self._body_measurement.style_updated(self))

    def _size_updated(self, size, virtual_size, container_size, layout=True):
        changed = super()._size_updated(size, virtual_size, container_size, layout)
        self._update_body_measurement(self._body_measurement.resized(size))
        return changed

    @property
    def selection_style(self):
        from textual.style import Style
        return Style.from_styles(self.screen.get_component_styles('screen--selection')).rich_style

    def render_lines(self, crop):
        return self._body_measurement.render(self, crop, super().render_lines)

    def get_selection(self, selection):
        return self._body_measurement.get_selection(self, selection, super().get_selection)

    async def prepare_input(self, event):
        # Native controls are actual resources, not pixels. Restore them at
        # interaction, retaining read-only rows for ordinary scroll/reentry.
        if self.body_dormant:
            await self.materialize_interactive_body()
            # Native input routing must select its target after the new scene
            # commits, outside the mutation lock; no synthetic event replay.
            painted = asyncio.Event()
            self.screen.call_after_refresh(painted.set)
            await painted.wait()

    async def materialize_interactive_body(self):
        """Acquire actual native controls through their original body owners."""
        await self.materialize_body()
        for child in self.child_bodies():
            await child.materialize_interactive_body()

    async def materialize_body(self):
        if not self.body_dormant or not self.is_attached or self._closing:
            return
        await self._body_measurement.materialize(self)

    def publish_body(self, work: Callable[[], Awaitable[None | bool | BodyMeasurement]], *, exit_on_error=False) -> AwaitComplete:
        """Source updates and reentry share the original materialization worker."""
        operation = self._body_measurement.start_materialization(self, work, exit_on_error=exit_on_error)
        return AwaitComplete(operation.materialize(self))

    def batch(self):
        return self._body_measurement.batch(self, super().batch)

    async def recompose(self):
        # Native recompose is also a publication, including direct callers.
        # An admitted writer already owns its resource and must not join itself.
        await self._body_measurement.recompose(self, super().recompose)


    async def materialize_native_body(self):
        raise NotImplementedError

    def reconstructible_children(self):
        raise NotImplementedError

    def retire_body_resources(self):
        pass

    def retire_body(self):
        # Acquire pixels synchronously. The viewport can capture its bounded
        # cohort from one publication before any preparation or pruning awaits.
        return self._body_measurement.retire(self)

    @asynccontextmanager
    async def retirement_custody(self):
        async with self.lock:
            yield True

    def retire_native_body(self, current):
        if not self.body_ready or not self.is_attached:
            return BodyMeasurement.retire(current, self)
        if self.lock.is_locked or self._body_viewport is None:
            return BodyMeasurement.retire(current, self)
        if self._body_viewport.requires_body(self):
            return BodyMeasurement.retire(current, self)
        children = self.reconstructible_children()
        if not children:
            return BodyMeasurement.retire(current, self)
        # The bounded retirement cohort owns this acquisition. A live body
        # may have no committed offscreen placement; request its complete
        # geometry before capture instead of forcing it on every scroll.
        capture = current.capture_requested()
        self._update_body_measurement(capture)
        current = capture
        sources = self.prepared_paint_sources()
        if not self.prepared_paint_is_current(sources):
            return BodyMeasurement.retire(current, self)
        paint = self.capture_native_paint(current, sources=sources)
        return self.finish_native_retirement(current, children, paint, sources)

    def prepared_paint_sources(self):
        """Borrow original committed resources, including nested body contents."""
        return tuple((child, child.prepared_content)
                     for child in walk_depth_first(self, with_root=True)
                     if isinstance(child, PreparedPaintSource))

    def prepared_paint_is_current(self, sources):
        current = self.prepared_paint_sources()
        return (len(current) == len(sources)
                and all(owner is original and resource is not None and resource is prepared
                        for (owner, resource), (original, prepared) in zip(current, sources))
                and all(child.body_ready for child in walk_depth_first(self, with_root=False)
                        if isinstance(child, ViewportBody)))

    def capture_native_paint(self, current, *, sources=None):
        """Capture once for retirement and preceding-source publication."""
        if sources is None:
            sources = self.prepared_paint_sources()
        unprepared = current.capture_unavailable()
        if (not current.ready(self) or not self.is_attached or self.lock.is_locked
                or any(self in endpoint.walk_ancestors(with_self=True)
                       for endpoint in self.screen._interaction_widgets())
                or not self.prepared_paint_is_current(sources)):
            return unprepared.prepare_publication(self)
        compositor = self.screen._compositor
        style_revision = self._subtree_style_revision
        paint_state = self._resolved_paint_state()
        root_empty = self.is_empty
        captured = tuple(compositor.published_geometry((self,)))
        if not captured:
            return unprepared.prepare_publication(self)
        _body, placement = captured[0]
        size, rows, geometry = compositor.render_subtree_strips(self, placement)
        # Arrangement may acquire a different width and start preparation.
        # Its provisional rows cannot become the source's retained resource.
        if not self.prepared_paint_is_current(sources):
            return unprepared.prepare_publication(self)
        source_regions = current.capture_source_regions(self, placement, geometry)
        # The native map belongs to the synchronous capture. Retain only its
        # original source members and value geometry, never the widget graph.
        del geometry
        # Native capture already owns final styled terminal rows. Retain those
        # rows directly; rendering them again in Rich workers duplicates work
        # and serializes a resource that never leaves this process.
        content = PreparedRichContent(size.width, tuple(rows))
        widgets = self.materialized_widget_count

        async def measured():
            size_bytes = await self.app.preparation.run_thread(current.capture_cost, content, source_regions)
            if not self.prepared_paint_is_current(sources):
                return unprepared
            return current.captured(
                widgets=widgets, content=content,
                resource_bytes=size_bytes, style_revision=style_revision, paint_state=paint_state,
                root_empty=root_empty, source_regions=source_regions,
            )

        return measured()

    def retirement_current(self, current):
        """Borrow current viewport demand again after asynchronous capture."""
        return (self._body_measurement is current and self.is_attached and not self._closing
                and self._body_viewport is not None
                and not self._body_viewport.requires_body(self))

    async def release_native_body(self, current):
        if not self.body_ready or not self.retirement_current(current):
            return False
        children = self.reconstructible_children()
        if not children:
            return False
        async with self.retirement_custody() as can_commit:
            if not can_commit or not self.retirement_current(current):
                return False
            self._update_body_measurement(current.source_retired(self))
            self.retire_body_resources()
            await self.remove_children(children)
        return True

    async def finish_native_retirement(self, current, children, paint, sources):
        rendered = await paint
        # The original state is the captured source/width/style lifetime. An
        # asynchronous change invalidates it rather than copying a revision.
        if not self.retirement_current(current):
            return False
        if not rendered.ready(self):
            return False
        async with self.retirement_custody() as can_commit:
            if (not can_commit or not self.retirement_current(current) or not rendered.ready(self)
                    or not self.prepared_paint_is_current(sources)):
                return False
            self._update_body_measurement(rendered)
            self.retire_body_resources()
            await self.remove_children(children)
        return True

    async def restore_body(self):
        previous = self._body_measurement
        await previous.restore(self)
        return self._body_measurement is not previous

    @height_dependency(NATIVE_WIDGET_HEIGHT)
    def get_content_height(self, container, viewport, width):
        native_height = super().get_content_height
        # Allocation changes the borrowed resource through its current owner.
        # A preceding height supplier must never overwrite the worker chain.
        self._update_body_measurement(self._body_measurement.allocated(width))
        measurement = self._body_measurement
        height = measurement.height(self, width, lambda: native_height(container, viewport, width))
        if self._body_measurement is measurement:
            # Record native output without retiring its input measurement.
            # A width invalidation already replaced this resource above.
            self._body_measurement = measurement.measured(width, height)
        return height

    def get_content_width(self, container, viewport):
        native_width = super().get_content_width
        return self._body_measurement.content_width(
            self, lambda: native_width(container, viewport))

    def on_unmount(self):
        if self._body_viewport is not None:
            self._body_viewport.discard(self)
            self._body_viewport = None
        self._update_body_measurement(self.live_body_measurement())

    def on_mount(self):
        from toad.screens.workspace import WorkspaceScreen
        from toad.widgets.history_anchor import HistoryWindow
        if isinstance(self.screen, WorkspaceScreen):
            outer_body = None
            for ancestor in self.walk_ancestors():
                if isinstance(ancestor, ViewportBody):
                    outer_body = ancestor
                if isinstance(ancestor, HistoryWindow):
                    self._body_viewport = ancestor.document_viewport
                    # Native resource admission stays at the outer boundary.
                    # Nested bodies use that SAME window's preparation worker,
                    # rather than queuing worker waits on their own input FIFO.
                    if outer_body is None:
                        self._body_viewport.register(self)
                    self.request_body_preparation()
                    return
        self.request_body_preparation()

    def on_worker_static_extent_ready(self, _event):
        # The prepared sender commits readiness for visible publication as
        # well as complete retirement capture. Nested boundaries keep bubbling
        # until the registered body, which owns both demands in this viewport.
        viewport = self._body_viewport
        if viewport is not None and (self.body_capture_pending or viewport.requires_body(self)):
            viewport.request()


class ViewportPresentation:
    """Own the selected screen's window membership and paint preparation."""

    def __init__(self, screen):
        self._screen = ref(screen)
        self.windows = WeakSet()
        self.anchors = set()
        self.document_admissions = None

    @property
    def screen(self):
        screen = self._screen()
        if screen is None:
            raise ReferenceError("The viewport presentation has been retired")
        return screen

    def release(self, window) -> None:
        """Retire native observers before their optional window leaves the DOM."""
        self.windows.discard(window)
        self.anchors.discard(window)
        self.screen.screen_layout_refresh_signal.unsubscribe(window)
        window.retire_presentation_wait()

    def request(self) -> None:
        for window in self.windows:
            window.document_viewport.request()

    def suspend(self) -> None:
        for window in self.windows:
            window.retire_presentation_wait()
            window.document_viewport.request()
        for window in self.anchors:
            window.retire_presentation_wait()

    @asynccontextmanager
    async def batch(self, body, native_batch):
        """Membership writes borrow the window's committed layout geometry."""
        from toad.widgets.history_anchor import HistoryWindow

        for ancestor in body.walk_ancestors():
            if isinstance(ancestor, HistoryWindow):
                if ancestor in self.windows:
                    async with ancestor.preserve_history(None, root=body):
                        async with body.lock:
                            yield
                    return
                break
        async with native_batch():
            yield

    def frame_windows(self):
        # Stopping preparation does not remove a still-visible native tree.
        # Its membership owns paint through the final prune, including close.
        return (window for window in self.windows
                if window.document_viewport.membership.displayed())

    @contextmanager
    def using_document_inputs(self):
        """Lend one native acquisition to this synchronous preparation/paint.

        Bound resources own their original source and native CSS participant.
        Layout precedes this borrow; publication and pointer callbacks follow
        it. Neither a later frame nor an asynchronous writer inherits it.
        """
        from textual.document._paint import DocumentPresentation

        if self.document_admissions is not None:
            yield
            return
        # Rendering consumes clipped native bodies, not all text retained by a
        # visible message container. Mutation admission also asks its original
        # retained ancestors whether they can paint the preceding publication.
        bodies = dict.fromkeys(body for _window, body in self.visible_bodies(self.windows))
        for root in self.mutation_roots():
            for owner in root.walk_ancestors(with_self=True):
                if isinstance(owner, ViewportBody):
                    bodies[owner] = None
        participants = tuple(body for body in bodies
                             if body._body_measurement.published_document_paint is not None)
        self.document_admissions = DocumentPresentation.acquire_admissions(participants)
        try:
            yield
        finally:
            self.document_admissions = None

    def geometry_targets(self) -> tuple[Widget, ...]:
        """Keep reader anchors and live body boxes in the same native layout.

        Capturing an offscreen body needs its current box, not another full
        scene arrangement. Retained rows already own their extent; they do not
        require a live descendant layout just to scroll back into view.
        """
        windows = tuple(self.frame_windows())
        return tuple(dict.fromkeys((
            *(target for window in windows
              for target in window.history_geometry_targets()),
            *(target for window in windows
              for target in window.document_viewport.geometry_targets()),
        )))

    def visible_bodies(self, windows):
        """Select paint bodies once from the original scene and native owner.

        Nested windows own their own bodies. An enclosing window must not
        acquire their readiness or schedule their reconstruction as its work.
        This cohort is synchronous; it is not another membership registry.
        """
        from toad.widgets.history_anchor import HistoryWindow

        windows = set(windows)
        for body in self.screen._compositor.visible_widgets:
            if isinstance(body, ViewportBody):
                for ancestor in body.walk_ancestors():
                    if isinstance(ancestor, HistoryWindow):
                        if ancestor in windows:
                            yield ancestor, body
                        break

    def mutation_roots(self, windows: tuple[Widget, ...] | None = None) -> tuple[Widget, ...]:
        """Use the acquired frame windows, or acquire them for layout/input."""
        if windows is None:
            windows = tuple(self.frame_windows())
        displayed = dict.fromkeys(windows)
        for anchor in self.anchors:
            if anchor not in displayed and anchor.document_viewport.membership.displayed():
                displayed[anchor] = None
        return tuple(root for window in displayed if window.is_attached
                     if (root := window.history_mutation_root) is not None)

    def prepare(self) -> tuple[Widget, ...]:
        from textual.document._paint import DocumentPresentation

        with self.using_document_inputs():
            screen = self.screen
            if not screen.is_current:
                return ()
            # This synchronous admission consumes one cohort from the original
            # membership owner. Mutation, body readiness and follow checks don't
            # independently select the same windows again within the same frame.
            windows = tuple(self.frame_windows())
            mutations = self.mutation_roots(windows)
            # A retained body is the original paint owner for its whole subtree.
            # Its new source may keep changing while those exact strips publish.
            # Native layout and callback custody still borrow every mutation root;
            # only paint exclusion ends when that owner has valid retained pixels.
            deferred = dict.fromkeys(root for root in mutations
                                     if not any(isinstance(owner, ViewportBody)
                                                and owner.body_retained_paint_ready
                                                for owner in root.walk_ancestors(with_self=True)))
            pending_windows = {window for window in windows
                               if window.history_mutating()}
            # Each source owns its pending paint. Native publication derives the
            # blocked geometry; this owner neither masks regions nor stops chrome.
            for window, body in self.visible_bodies(windows):
                if any(root is body or root in body.ancestors or body in root.ancestors
                       for root in mutations):
                    continue
                if not body.body_ready:
                    window.document_viewport.request()
                    deferred[body] = None
                    pending_windows.add(window)
            for window in windows:
                if window not in pending_windows and window.check_follow():
                    # Native UpdateScroll owns reflow. Hold this source's old
                    # coordinates until that update, without holding other roots.
                    deferred[window] = None
                    # Follow changes an original input synchronously. Custom
                    # native pseudos may derive from it; the same paint scope
                    # must consume the current acquisition after that change.
                    self.document_admissions = DocumentPresentation.acquire_admissions(
                        self.document_admissions)
            return tuple(deferred)


class WindowMembership:
    """One window's registration in its screen presentation."""
    def __init__(self, window):
        self.window = ref(window)
        self.presentation = window.screen.viewport_presentation
        self.bind(self.presentation)

    def bind(self, presentation):
        self.retire()
        self.presentation = presentation
        window = self.window()
        self.presentation.windows.add(window)
        self.presentation.screen.screen_layout_refresh_signal.subscribe(
            window, window.on_viewport_layout,
        )

    def displayed(self) -> bool:
        """Native ancestry owns visibility, including a window mounted late.

        Hydration can finish after its logical session is hidden. Its newly
        registered window cannot participate in that screen's frame merely
        because no viewport suspension preceded its construction.
        """
        window = self.window()
        return (self.presentation.screen.is_current
                and all(node.display for node in window.walk_ancestors(with_self=True)))

    def retire(self):
        window = self.window()
        self.presentation.windows.discard(window)
        self.presentation.anchors.discard(window)
        self.presentation.screen.screen_layout_refresh_signal.unsubscribe(window)


class DocumentViewport:
    """One bounded warm working set for a history window, not one per message."""

    def __init__(self, window, *, budget: PresentationBudget | None = None):
        self.budget = budget if budget is not None else PresentationBudget(
            buffer_viewports=window.app.settings.ui.history_buffer_viewports,
        )
        self.lookahead = DirectionalPreparation(self)
        self._settle_timer = None
        self._window = ref(window)
        self.owners = WeakSet()
        self._warm = OrderedDict()
        self.admitted_bodies = set()
        self.body_evictions = 0
        self._pending = False
        self._worker = None
        self._suspended = False
        window.watch(window, "scroll_y", self.scroll_changed, init=False)
        self.membership = WindowMembership(window)

    @property
    def window(self):
        window = self._window()
        if window is None:
            raise ReferenceError("The document viewport's window has been retired")
        return window

    def accepts_frame(self) -> bool:
        """Only this resource's bound lifetime participates in publication."""
        return not self._suspended and self.membership.displayed()

    def register(self, owner: ViewportBody) -> None:
        self.owners.add(owner)
        # Declare custody before layout so its live box is a geometry target.
        # Preparation consumes the committed frame, not a partially mounted
        # tree whose geometry query would manufacture a full-scene layout.
        # The existing frame owner batches this window's initial callbacks and
        # the native message pump revokes them when the window is retired.
        self.request_after_refresh()

    def discard(self, owner: ViewportBody) -> None:
        self.owners.discard(owner)
        self._warm.pop(ref(owner), None)
        self.admitted_bodies.discard(owner)

    def retains_body(self, owner: ViewportBody) -> bool:
        """A source boundary borrows admission from its original text bodies.

        Message containers and independently prepared paragraphs have distinct
        identities. Their declared preparation targets carry the ownership
        relation; native registration or container identity is not admission.
        """
        return any(body in self.admitted_bodies for body in owner.body_preparation_targets())

    @property
    def source_tail(self) -> ViewportBody | None:
        """The last document body owns this window's current source edge.

        An older message can retain a partial range after a newer message is
        published. That old range cannot revoke the newer message's tail.
        Native document order already owns their relation; warm membership
        and registration order do not supply another chronology.
        """
        return next(self.body_roots(reverse=True), None)

    @property
    def source_tail_visible(self) -> bool:
        last = self.source_tail
        return last is None or not last.has_newer_source

    def requires_body(self, owner, *, visible=None, protected=None) -> bool:
        """Native exposure and current interaction own source admission."""
        if owner._body_viewport is not self:
            return False
        if visible is None:
            visible = self.window.screen._compositor.visible_widgets
        if owner in visible:
            return True
        if protected is None:
            protected = self.protected()
        if owner in protected:
            return True
        if owner.measured_rows or owner.body_ready:
            return False
        # An unfinished intrinsic source has no paint rectangle yet. Its
        # assigned native position still owns preparation exposure; excluding
        # it as invisible would require paint before admitting that same paint.
        # Borrow committed geometry only, without arranging or inventing rows.
        compositor = self.window.screen._compositor
        for _owner, placement in compositor.published_geometry((owner,)):
            region = placement.region
            clip = placement.clip.intersection(compositor.size.region)
            return (clip.y <= region.y < clip.bottom
                    and max(region.x, clip.x) < min(region.right, clip.right))
        return False

    def body_roots(self, *, reverse: bool = False):
        """Native document order, stopping at each registered body boundary.

        Descendants belong to that body's materialization, not to another
        viewport admission. Walk the original tree without expanding those
        descendants or keeping an independent order alongside native custody.
        """
        if not self.owners:
            return
        pending = list(self.window.children if reverse else reversed(self.window.children))
        while pending:
            node = pending.pop()
            if node in self.owners:
                yield node
            else:
                pending.extend(node.children if reverse else reversed(node.children))

    def preparation_roots(self):
        """Source boundaries lend independently positioned text resources.

        A message may span many screens. Its visible container neither admits
        all that text nor supplies a preparation unit or measured row density.
        Source chronology and paging still belong to body_roots().
        """
        for owner in self.body_roots():
            for source in owner.body_preparation_targets():
                if source._body_viewport is self and source.is_attached and not source._closing:
                    yield source

    def geometry_targets(self) -> tuple[Widget, ...]:
        """Each body's current resource owns its actual geometry demand."""
        return tuple(dict.fromkeys(
            target
            for owner in self.owners
            for target in owner.body_geometry_targets()
        ))

    @property
    def materialized_widget_count(self) -> int:
        """Actual native body custody in this window's resource scope."""
        return sum(owner.materialized_widget_count for owner in self.owners)

    @property
    def retained_source_bytes(self) -> int:
        """Source retained by this window's registered body boundaries."""
        return sum(owner.retained_source_bytes for owner in self.owners)

    @property
    def retained_paint_bytes(self) -> int:
        """Prepared paint still owned by the same registered bodies."""
        return sum(owner.retained_paint_bytes for owner in self.owners)

    @property
    def visible_body_rows(self) -> float:
        """Measured native density, derived from the current viewport owners."""
        visible = self.window.screen._compositor.visible_widgets
        rows = [owner.measured_rows for owner in self.preparation_roots()
                if owner in visible and owner.measured_rows]
        return sum(rows) / len(rows) if rows else max(1, self.window.size.height)

    def admission_candidates(self, *, required=(), ahead=(), resources=None):
        candidates = dict.fromkeys((*required, *ahead, *(owner
            for key in reversed(self._warm.values()) if (owner := key()) is not None)))
        resources = set(self.preparation_roots() if resources is None else resources)
        return tuple(owner for owner in candidates if owner in resources)

    def admission(self, *, required=(), ahead=(), resources=None):
        # Native preparation prices the last actual tree BEFORE restoration.
        # Retained paint is admitted independently below; retaining rows is
        # not permission to recreate every hidden control in that resource.
        return self.budget.admit(
            self.admission_candidates(required=required, ahead=ahead, resources=resources), required,
            self.window.size.height, self.window.app.preparation.max_bytes,
        )

    def _trim_warm(self, *, required=(), ahead=(), resources=None):
        resources = tuple(self.preparation_roots() if resources is None else resources)
        self.admitted_bodies = self.budget.admit_paint(
            self.admission_candidates(required=required, ahead=ahead, resources=resources), required,
            self.window.app.preparation.max_bytes,
        )
        admitted = self.admitted_bodies
        for owner in resources:
            if owner in admitted:
                owner.retain_paint()
            else:
                owner.release_paint()
        for key in tuple(self._warm):
            if key() not in admitted:
                self._warm.pop(key)
                self.body_evictions += 1
        for owner in reversed(ahead):
            if owner in admitted:
                key = ref(owner)
                self._warm[key] = key
                self._warm.move_to_end(key)
        for owner in required:
            key = ref(owner)
            self._warm[key] = key
            self._warm.move_to_end(key)
        return admitted

    def request(self, *_args) -> None:
        if (not self.owners or not self.accepts_frame()
                or not self.window.is_attached or self.window._closing):
            return
        self._pending = True
        if self._worker is None:
            self._worker = self.window.run_worker(partial(self._reconcile), group="viewport-bodies")

    def request_after_refresh(self) -> None:
        """Prepare the latest viewport after native geometry has committed.

        Motion records demand immediately; it cannot reconcile bodies against
        the preceding visible map. Source publishers retain distinct callback
        scopes, while the window owns its one body admission and frame work.
        """
        window = self.window
        if not self.accepts_frame() or not window.is_attached or window._closing:
            return
        for history in tuple(window.histories):
            history.request_preparation()
        window.screen.frame_presentation.defer(window, self.prepare_viewport)

    def prepare_viewport(self) -> None:
        if self.accepts_frame() and self.window.is_attached and not self.window._closing:
            self.window.prepare_viewport()
            self.request()

    def scroll_changed(self, *_args) -> None:
        # Native scroll is the demand producer. Screen-wide layout (including
        # this working set's own pruning) is not another scroll or admission.
        if (not self.accepts_frame() or not self.window.is_attached
                or self.window._closing or self.window._restoring):
            return
        if self.lookahead.observe(self.window.scroll_y):
            self._schedule_settle()
        self.request_after_refresh()

    def destination(self) -> None:
        self.lookahead.observe(self.window.scroll_y)
        self.lookahead.destination(self.window.size.height)
        self._schedule_settle()
        self.request_after_refresh()

    def _schedule_settle(self) -> None:
        if self._settle_timer is not None:
            self._settle_timer.stop()
        self._settle_timer = self.window.set_timer(self.lookahead.idle_seconds, self._settle)

    def _settle(self) -> None:
        self._settle_timer = None
        self.lookahead.settle()
        self.request_after_refresh()

    async def suspend_source(self) -> None:
        """Finish the departing source's layout transactions before rebinding."""
        self._suspended = True
        if self._settle_timer is not None:
            self._settle_timer.stop()
            self._settle_timer = None
        self.lookahead.settle()
        self._pending = False
        self.window.retire_presentation_wait()
        worker, self._worker = self._worker, None
        if worker is not None:
            worker.cancel()
            try:
                await worker.wait()
            except WorkerCancelled:
                pass
        for owner in tuple(self.owners):
            owner.require_native_body()

    def resume_source(self) -> None:
        self._suspended = False
        # Resume restores the native geometry target declaration as well as
        # source custody. Reconciliation consumes that publication; it must
        # not capture from the departing/parked scene or manufacture its boxes.
        if self.geometry_targets():
            self.window.refresh(layout=True)
        self.request_after_refresh()

    async def close(self) -> None:
        """Release this working set before its window's final retirement."""
        await self.suspend_source()
        self._warm.clear()
        self.owners.clear()
        self.admitted_bodies.clear()

    def protected(self) -> set[Widget]:
        screen = self.window.screen
        protected = set()
        for endpoint in (*screen._interaction_widgets(), *self.window.reader_bodies):
            for node in endpoint.walk_ancestors(with_self=True):
                if not isinstance(node, Widget) or node is self.window:
                    break
                protected.add(node)
        if (restoration := self.window.history_restoration) is not None:
            protected.update(restoration.required_bodies(self.window))
        return protected

    @property
    def visible_bodies_ready(self) -> bool:
        # Frame admission and source preparation ask the same native owner.
        # A nested body still contributes even when its outer fragment owns
        # retirement; a nested window contributes to its own viewport only.
        window = self.window
        return all(body.body_ready for _window, body in
                   window.screen.viewport_presentation.visible_bodies((window,)))

    async def _reconcile(self) -> None:
        try:
            while (self._pending and self.owners and self.accepts_frame()
                   and self.window.is_attached and not self.window._closing):
                self._pending = False
                screen = self.window.screen
                visible = screen._compositor.visible_widgets
                protected = self.protected()
                owners = tuple(dict.fromkeys(self.preparation_roots()))
                required = tuple(owner for owner in owners
                                 if self.requires_body(owner, visible=visible, protected=protected))
                # Warm admission and retirement belong to outer resources.
                # Publication also needs nested bodies in the original visible
                # cohort; a ready outer fragment cannot prepare their rows.
                foreground = tuple(dict.fromkeys((
                    *required,
                    *self.window.reader_bodies,
                    *(body for _window, body in screen.viewport_presentation.visible_bodies((self.window,))),
                )))
                for owner in foreground:
                    owner.require_native_body()
                # Reuse the same body admission and worker. Restore only the
                # neighboring destination bodies, not every skipped record.
                demand = self.lookahead.demand
                ahead_owners = []
                visible_indexes = [index for index, node in enumerate(owners) if node in visible]
                if visible_indexes:
                    count = self.lookahead.admission(self.budget, self.window.size.height)
                    runway = self.budget.runway(
                        owners, min(visible_indexes), max(visible_indexes) + 1,
                        self.window.size.height,
                    )
                    predicted = demand.neighbors(
                        owners, min(visible_indexes), max(visible_indexes) + 1, count,
                    )
                    ahead_owners = list(dict.fromkeys(demand.body_order(runway, predicted)))
                admitted = self._trim_warm(required=required, ahead=ahead_owners, resources=owners)
                # Admission retains a body's bounded presentation resource,
                # not its live descendant tree. Offscreen warm bodies paint
                # their retained rows on reentry; only visible or interaction
                # protected bodies need their current native controls.
                retained = protected | visible.keys()
                # One foreground cohort produces readiness before frame
                # admission. Per-body paint waits would hold this worker while
                # the remaining visible dormant bodies reject that same frame.
                restored = ()
                if foreground:
                    started = monotonic()
                    restored = await self._restore_bodies(foreground, None, demand)
                    if any(owner in visible for owner in restored):
                        self.lookahead.delivered(monotonic() - started)
                # Restoration can publish new geometry, and native input can
                # move the viewport while it awaits. The existing request
                # owns that invalidation: serve its visible cohort before
                # retiring or predicting from the preceding scene.
                if self._pending:
                    continue
                if any(not owner.body_ready for owner in foreground):
                    # Exposed source owns this frame first. Its preparation
                    # and native publication already request reconciliation;
                    # do not fill their renderer with hidden capture work.
                    return
                # The same foreground worker admits message source ranges.
                # Restore its whole visible cohort first; one range's reader
                # compensation must not wait on an unstarted sibling restore.
                if not screen.frame_presentation.awaits_publication(self.window, self.prepare_viewport):
                    # The next source edge uses committed frame geometry.
                    # Waiting for that receipt does not stop retirement or
                    # preparation needed to make the same frame publishable.
                    async with asyncio.TaskGroup() as source_preparation:
                        source_tasks = [source_preparation.create_task(owner.prepare_visible_source())
                                        for owner in foreground]
                    if any(task.result() for task in source_tasks):
                        self.request_after_refresh()
                        return
                if self._pending:
                    continue
                retiring = tuple(owner for owner in owners
                                 if owner.is_attached and not owner._closing
                                 and owner not in retained and not owner.body_dormant)
                # Complete geometry belongs only to the existing bounded
                # retirement cohort. Keep its unfinished acquisitions ahead
                # of new work; a missing resource must not cause every hidden
                # body's paragraphs to start preparation in the same frame.
                retiring = tuple(owner for owner in retiring if owner.body_capture_pending) + tuple(
                    owner for owner in retiring if not owner.body_capture_pending)
                retiring = retiring[:self.budget.admission_items]
                retired_owners = []
                for first in range(0, len(retiring), self.budget.admission_items):
                    # Each call captures its original rows now; tasks only
                    # prepare detached rows and validate/prune afterward.
                    batch = retiring[first:first + self.budget.admission_items]
                    with ExitStack() as captures:
                        operations = []
                        for owner in batch:
                            operation = owner.retire_body()
                            captures.callback(operation.close)
                            operations.append(operation)
                        async with asyncio.TaskGroup() as preparations:
                            tasks = [preparations.create_task(operation)
                                     for operation in operations]
                        results = [task.result() for task in tasks]
                    for owner, retired in zip(batch, results):
                        if retired:
                            retired_owners.append(owner)
                            if owner in admitted:
                                key = ref(owner)
                                self._warm[key] = key
                                self._warm.move_to_end(key)
                    if any(results):
                        # Pruning retires the old scene. Continue from the next
                        # published layout, never lazily arrange it for capture.
                        self.request_after_refresh()
                    # Finish the admitted capture/prune batch, then reacquire
                    # demand. Offscreen housekeeping must not delay newly
                    # visible source behind the rest of an obsolete cohort.
                    if self._pending:
                        break
                if self._pending:
                    continue
                # Capturing rows changes the original body resource cost.
                # The same warm LRU admits or releases that paint resource.
                if retired_owners or restored:
                    admitted = self._trim_warm(required=required, ahead=ahead_owners)
                # Do not materialize a runway body that cannot be retained.
                # The original demand owns incoming direction priority.
                native_admission = self.admission(required=required, ahead=ahead_owners)
                ahead_owners = [owner for owner in ahead_owners
                                if owner in admitted and owner in native_admission]
                for first in range(0, len(ahead_owners), self.budget.admission_items):
                    if self._pending or not self.lookahead.accepts(demand):
                        break
                    batch = tuple(owner for owner in ahead_owners[first:first + self.budget.admission_items]
                                  if owner in admitted)
                    if not batch:
                        continue
                    restored = await self._restore_bodies(batch, None, demand)
                    # Live content or a width change can change actual cost.
                    # Re-admit the completed native batch before the next one.
                    if restored:
                        admitted = self._trim_warm(required=required, ahead=ahead_owners)
        finally:
            if self._worker is get_current_worker():
                self._worker = None

    async def _restore_bodies(
        self, owners: tuple[ViewportBody, ...], anchor: Widget | None, demand: PreparationDemand,
    ) -> tuple[ViewportBody, ...]:
        if (not self.window.is_attached or not self.accepts_frame()
                or not self.lookahead.accepts(demand)):
            return ()
        # The caller lends explicit native resources in viewport order. Do not
        # turn a visible container back into demand for its entire subtree.
        owners = tuple(dict.fromkeys(owner for owner in owners
                                     if owner.is_attached and not owner._closing
                                     and owner.body_dormant and not owner.body_ready))
        if not owners:
            return ()
        if anchor is None:
            anchor = self.window.reader_anchor(owners[0])
        async with AsyncExitStack() as mutation:
            if any(not owner.body_ready for owner in owners):
                await mutation.enter_async_context(self.window.preserve_reader(anchor))
            # Each original materialization worker acquires its prepared result
            # once. Source-page lookahead warms unmounted leaves separately;
            # repeating that work here delays every body before delivery begins.
            # Join this admitted cohort together under the same reader anchor,
            # retaining the runtime's existing worker and resource limits.
            async with asyncio.TaskGroup() as restoration:
                tasks = []
                for owner in owners:
                    if not self.accepts_frame() or not self.lookahead.accepts(demand):
                        break
                    if owner.is_attached and not owner._closing:
                        tasks.append((owner, restoration.create_task(owner.restore_body())))
            restored = tuple(owner for owner, task in tasks if task.result())
        if restored:
            # Native child composition and nested page publication produce
            # readiness. The same frame owns capture after compensated layout.
            self.request_after_refresh()
        return restored
